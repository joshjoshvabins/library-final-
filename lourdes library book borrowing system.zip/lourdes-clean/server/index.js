const express = require("express");
const cors = require("cors");
const session = require("express-session");
const { initDb } = require("./db");

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: "http://localhost:5173", credentials: true }));
app.use(express.json());
app.use(session({
  secret: "lourdes-library-2024",
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, secure: false, maxAge: 8 * 60 * 60 * 1000 }
}));

app.use("/api/auth",    require("./routes/auth"));
app.use("/api/books",   require("./routes/books"));
app.use("/api/members", require("./routes/members"));
app.use("/api/loans",   require("./routes/loans"));

app.use((err, req, res, next) => {
  console.error(err.message);
  res.status(500).json({ error: "Something went wrong." });
});

initDb();
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Server running → http://localhost:${PORT}`);
  console.log(`Login: admin / lourdes123`);
});
