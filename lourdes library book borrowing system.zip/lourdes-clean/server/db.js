const { DatabaseSync } = require("node:sqlite");
const path = require("path");

const db = new DatabaseSync(path.join(__dirname, "library.db"));

db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

function hashPw(plain) { return String(plain); }
function checkPw(plain, stored) { return String(plain) === String(stored); }

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student',
      member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      isbn TEXT UNIQUE,
      genre TEXT NOT NULL DEFAULT '',
      total_copies INTEGER NOT NULL DEFAULT 1,
      available_copies INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL UNIQUE COLLATE NOCASE,
      name TEXT NOT NULL,
      grade TEXT NOT NULL DEFAULT '',
      contact TEXT NOT NULL DEFAULT '',
      type TEXT NOT NULL DEFAULT 'student',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS loans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id),
      member_id INTEGER NOT NULL REFERENCES members(id),
      borrow_date TEXT NOT NULL DEFAULT (date('now')),
      due_date TEXT NOT NULL,
      return_date TEXT,
      fine REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      processed_by TEXT NOT NULL DEFAULT 'admin',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  if (db.prepare("SELECT COUNT(*) AS c FROM users").get().c === 0) {
    db.prepare("INSERT INTO users (username, password, role) VALUES (?,?,?)").run("admin", "lourdes123", "admin");
  }

  if (db.prepare("SELECT COUNT(*) AS c FROM books").get().c === 0) {
    const ins = db.prepare("INSERT INTO books (title, author, isbn, genre, total_copies, available_copies) VALUES (?,?,?,?,?,?)");
    [
      ["Noli Me Tangere", "José Rizal", "978-9712908088", "Filipino Classic", 4, 4],
      ["El Filibusterismo", "José Rizal", "978-9712908095", "Filipino Classic", 3, 3],
      ["Florante at Laura", "Francisco Balagtas", "978-9712927690", "Filipino Classic", 3, 3],
      ["Harry Potter and the Sorcerer's Stone", "J.K. Rowling", "978-0439708180", "Fantasy", 6, 6],
      ["The Alchemist", "Paulo Coelho", "978-0062315007", "Fiction", 5, 5],
      ["To Kill a Mockingbird", "Harper Lee", "978-0061935466", "Fiction", 3, 3],
      ["The Little Prince", "Antoine de Saint-Exupéry", "978-0156012195", "Classic", 4, 4],
      ["Sapiens", "Yuval Noah Harari", "978-0062316097", "Non-Fiction", 2, 2],
      ["Atomic Habits", "James Clear", "978-0735211292", "Self-Help", 3, 3],
      ["Charlotte's Web", "E.B. White", "978-0061124952", "Children", 3, 3],
    ].forEach(b => ins.run(...b));
  }

  if (db.prepare("SELECT COUNT(*) AS c FROM members").get().c === 0) {
    const insMember = db.prepare("INSERT INTO members (student_id, name, grade, contact, type) VALUES (?,?,?,?,?)");
    const insUser = db.prepare("INSERT INTO users (username, password, role, member_id) VALUES (?,?,?,?)");

    [
      ["2024-0001", "Maria Santos",    "Grade 10 - St. Joseph",  "09171234567", "student", "maria.santos",   "maria001"],
      ["2024-0002", "Juan Dela Cruz",  "Grade 9 - St. Mary",     "09182345678", "student", "juan.delacruz",  "juan002"],
      ["2024-0003", "Ana Reyes",       "Grade 11 - St. Peter",   "09193456789", "student", "ana.reyes",      "ana003"],
      ["2024-0004", "Carlos Mendoza",  "Grade 8 - St. Luke",     "09204567890", "student", "carlos.mendoza", "carlos004"],
      ["2024-0005", "Sofia Garcia",    "Grade 12 - St. John",    "09215678901", "student", "sofia.garcia",   "sofia005"],
      ["STAFF-001", "Ms. Liza Cruz",   "Head Librarian",         "09301234567", "staff",   "ms.liza",        "liza001"],
      ["STAFF-002", "Mr. Rico Santos", "Library Assistant",      "09312345678", "staff",   "mr.rico",        "rico001"],
    ].forEach(([sid, name, grade, contact, type, username, password]) => {
      const r = insMember.run(sid, name, grade, contact, type);
      insUser.run(username, password, type, r.lastInsertRowid);
    });
  }

  if (db.prepare("SELECT COUNT(*) AS c FROM loans").get().c === 0) {
    const ins = db.prepare("INSERT INTO loans (book_id, member_id, borrow_date, due_date, return_date, fine, status, processed_by) VALUES (?,?,?,?,?,?,?,?)");
    const fmt = d => d.toISOString().split("T")[0];
    const add = n => { const d = new Date(); d.setDate(d.getDate() + n); return fmt(d); };

    [[1,1,add(-10),add(4)],[4,2,add(-5),add(9)],[5,3,add(-3),add(11)],[2,4,add(-20),add(-6)],[7,5,add(-18),add(-4)]]
      .forEach(([b,m,bd,dd]) => {
        ins.run(b, m, bd, dd, null, 0, "active", "admin");
        db.prepare("UPDATE books SET available_copies = available_copies - 1 WHERE id = ?").run(b);
      });

    [[3,3,add(-30),add(-16),add(-18),0],[6,4,add(-25),add(-11),add(-12),0],[9,2,add(-40),add(-26),add(-28),0]]
      .forEach(([b,m,bd,dd,rd,f]) => ins.run(b, m, bd, dd, rd, f, "returned", "admin"));
  }

  console.log("Database ready.");
  return db;
}

function getDb() { return db; }

module.exports = { getDb, initDb, hashPw, checkPw };
