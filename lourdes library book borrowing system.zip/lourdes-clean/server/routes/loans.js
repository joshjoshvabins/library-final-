const express = require("express");
const { getDb } = require("../db");
const router = express.Router();

const FINE_PER_DAY = 10;

function requireAuth(req, res, next) {
  if (req.session?.loggedIn) return next();
  res.status(401).json({ error: "Unauthorized" });
}
function requireAdmin(req, res, next) {
  if (req.session?.loggedIn && req.session.role === "admin") return next();
  res.status(403).json({ error: "Admin only" });
}

function today() {
  return new Date().toISOString().split("T")[0];
}
function daysLate(dueDate) {
  const diff = Math.floor((new Date() - new Date(dueDate)) / 86400000);
  return diff > 0 ? diff : 0;
}

const LOAN_SELECT = `
  SELECT l.*, ('TXN-' || printf('%05d', l.id)) AS transaction_id,
         b.id AS book_id, b.title AS book_title, b.author AS book_author, b.isbn AS book_isbn,
         m.id AS member_id_num, m.student_id AS member_student_id, m.name AS member_name,
         m.grade AS member_grade, m.type AS member_type, m.contact AS member_contact,
         CASE WHEN l.status='active' AND date('now') > l.due_date THEN 1 ELSE 0 END AS is_overdue,
         CASE WHEN l.status='active' AND date('now') > l.due_date
           THEN CAST((julianday('now') - julianday(l.due_date)) AS INTEGER) * ${FINE_PER_DAY}
           ELSE l.fine END AS computed_fine
  FROM loans l
  JOIN books b ON b.id = l.book_id
  JOIN members m ON m.id = l.member_id
`;

router.get("/", requireAuth, (req, res) => {
  const { status, search, member_id } = req.query;
  let sql = LOAN_SELECT + " WHERE 1=1";
  const params = [];

  if (req.session.role !== "admin") {
    const mid = req.session.memberId;
    if (!mid) return res.json([]);
    sql += " AND l.member_id = ?";
    params.push(mid);
  } else if (member_id) {
    sql += " AND l.member_id = ?";
    params.push(member_id);
  }

  if (status === "active")   sql += " AND l.status = 'active'";
  if (status === "returned") sql += " AND l.status = 'returned'";
  if (status === "overdue")  sql += " AND l.status = 'active' AND date('now') > l.due_date";

  if (search) {
    sql += " AND (b.title LIKE ? OR m.name LIKE ? OR m.student_id LIKE ? OR printf('%05d', l.id) LIKE ?)";
    params.push(`%${search}%`, `%${search}%`, `%${search}%`, `%${search}%`);
  }

  sql += " ORDER BY l.id DESC";
  res.json(getDb().prepare(sql).all(...params));
});

router.get("/stats/dashboard", requireAuth, (req, res) => {
  const db = getDb();
  const tod = today();

  if (req.session.role !== "admin") {
    const mid = req.session.memberId;
    if (!mid) return res.json({ active: 0, overdue: 0, total: 0, fines: 0 });
    return res.json({
      active:  db.prepare("SELECT COUNT(*) AS n FROM loans WHERE member_id=? AND status='active'").get(mid).n,
      overdue: db.prepare("SELECT COUNT(*) AS n FROM loans WHERE member_id=? AND status='active' AND due_date<?").get(mid, tod).n,
      total:   db.prepare("SELECT COUNT(*) AS n FROM loans WHERE member_id=?").get(mid).n,
      fines:   db.prepare("SELECT COALESCE(SUM(fine),0) AS n FROM loans WHERE member_id=? AND status='returned'").get(mid).n,
    });
  }

  res.json({
    totalBooks:     db.prepare("SELECT COALESCE(SUM(total_copies),0) AS n FROM books").get().n,
    totalMembers:   db.prepare("SELECT COUNT(*) AS n FROM members WHERE status='active'").get().n,
    borrowed:       db.prepare("SELECT COUNT(*) AS n FROM loans WHERE status='active'").get().n,
    overdue:        db.prepare("SELECT COUNT(*) AS n FROM loans WHERE status='active' AND due_date<?").get(tod).n,
    totalFines:     db.prepare("SELECT COALESCE(SUM(fine),0) AS n FROM loans WHERE status='returned'").get().n,
    totalTxns:      db.prepare("SELECT COUNT(*) AS n FROM loans").get().n,
    availableBooks: db.prepare("SELECT COALESCE(SUM(available_copies),0) AS n FROM books").get().n,
  });
});

router.get("/:id", requireAuth, (req, res) => {
  const loan = getDb().prepare(LOAN_SELECT + " WHERE l.id = ?").get(req.params.id);
  if (!loan) return res.status(404).json({ error: "Loan not found." });
  if (req.session.role !== "admin" && loan.member_id_num !== req.session.memberId)
    return res.status(403).json({ error: "Access denied." });
  res.json(loan);
});

router.post("/", requireAdmin, (req, res) => {
  const { book_id, member_id, due_date, notes } = req.body || {};
  if (!book_id)   return res.status(400).json({ error: "Please select a book." });
  if (!member_id) return res.status(400).json({ error: "Please select a member." });
  if (!due_date)  return res.status(400).json({ error: "Please set a due date." });
  if (due_date <= today()) return res.status(400).json({ error: "Due date must be after today." });

  const db = getDb();
  const book = db.prepare("SELECT * FROM books WHERE id = ?").get(book_id);
  if (!book) return res.status(404).json({ error: "Book not found." });
  if (book.available_copies <= 0) return res.status(400).json({ error: "No copies available." });

  const member = db.prepare("SELECT * FROM members WHERE id = ?").get(member_id);
  if (!member) return res.status(404).json({ error: "Member not found." });
  if (member.status !== "active") return res.status(400).json({ error: "Member account is inactive." });

  if (db.prepare("SELECT id FROM loans WHERE book_id=? AND member_id=? AND status='active'").get(book_id, member_id))
    return res.status(400).json({ error: "This member already has this book borrowed." });

  try {
    db.exec("BEGIN");
    const r = db.prepare(
      "INSERT INTO loans (book_id, member_id, borrow_date, due_date, notes, processed_by) VALUES (?,?,?,?,?,?)"
    ).run(book_id, member_id, today(), due_date, notes?.trim() || "", req.session.username);
    db.prepare("UPDATE books SET available_copies = available_copies - 1 WHERE id = ?").run(book_id);
    db.exec("COMMIT");
    res.status(201).json(getDb().prepare(LOAN_SELECT + " WHERE l.id = ?").get(r.lastInsertRowid));
  } catch (err) {
    try { db.exec("ROLLBACK"); } catch (_) {}
    res.status(500).json({ error: "Failed to issue book. Please try again." });
  }
});

router.patch("/:id/return", requireAdmin, (req, res) => {
  const db = getDb();
  const loan = db.prepare("SELECT * FROM loans WHERE id = ?").get(req.params.id);
  if (!loan) return res.status(404).json({ error: "Loan not found." });
  if (loan.status === "returned") return res.status(400).json({ error: "Already returned." });

  const fine = daysLate(loan.due_date) * FINE_PER_DAY;
  try {
    db.exec("BEGIN");
    db.prepare("UPDATE loans SET status='returned', return_date=?, fine=? WHERE id=?").run(today(), fine, loan.id);
    db.prepare("UPDATE books SET available_copies = available_copies + 1 WHERE id = ?").run(loan.book_id);
    db.exec("COMMIT");
    res.json(getDb().prepare(LOAN_SELECT + " WHERE l.id = ?").get(loan.id));
  } catch (err) {
    try { db.exec("ROLLBACK"); } catch (_) {}
    res.status(500).json({ error: "Failed to process return. Please try again." });
  }
});

module.exports = router;
