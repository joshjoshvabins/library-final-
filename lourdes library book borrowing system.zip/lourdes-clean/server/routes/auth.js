const express = require("express");
const { getDb, checkPw } = require("../db");
const router = express.Router();

function requireAuth(req, res, next) {
  if (req.session?.loggedIn) return next();
  res.status(401).json({ error: "Please log in first." });
}

function requireAdmin(req, res, next) {
  if (req.session?.loggedIn && req.session.role === "admin") return next();
  res.status(403).json({ error: "Admin access required." });
}

function buildUser(u) {
  return {
    id: u.id,
    username: u.username,
    role: u.role,
    name: u.member_name || "Administrator",
    student_id: u.student_id || null,
    grade: u.grade || null,
    contact: u.contact || null,
    member_id: u.member_id || null,
    member_type: u.member_type || null,
  };
}

const USER_SQL = `
  SELECT u.id, u.username, u.password, u.role, u.member_id, u.is_active,
         m.name AS member_name, m.student_id, m.grade, m.contact, m.type AS member_type
  FROM users u
  LEFT JOIN members m ON m.id = u.member_id
`;

router.post("/login", (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password)
    return res.status(400).json({ error: "Username and password are required." });

  const user = getDb().prepare(USER_SQL + " WHERE u.username = ? COLLATE NOCASE").get(String(username).trim());

  if (!user || !checkPw(password, user.password))
    return res.status(401).json({ error: "Incorrect username or password." });

  if (!user.is_active)
    return res.status(403).json({ error: "Your account has been deactivated. Contact the librarian." });

  req.session.loggedIn = true;
  req.session.userId   = user.id;
  req.session.username = user.username;
  req.session.role     = user.role;
  req.session.memberId = user.member_id || null;

  res.json({ ok: true, user: buildUser(user) });
});

router.post("/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

router.get("/me", (req, res) => {
  if (!req.session?.loggedIn)
    return res.status(401).json({ error: "Not logged in." });

  const user = getDb().prepare(USER_SQL + " WHERE u.id = ?").get(req.session.userId);
  if (!user) return res.status(401).json({ error: "Session expired." });

  res.json({ ok: true, user: buildUser(user) });
});

router.post("/register", (req, res) => {
  const { full_name, student_id, grade, contact, type, username, password } = req.body || {};

  if (!String(full_name  || "").trim()) return res.status(400).json({ error: "Full name is required." });
  if (!String(student_id || "").trim()) return res.status(400).json({ error: "School ID is required." });
  if (!String(contact    || "").trim()) return res.status(400).json({ error: "Contact number is required." });
  if (!String(username   || "").trim()) return res.status(400).json({ error: "Username is required." });
  if (!password || String(password).length < 4)
    return res.status(400).json({ error: "Password must be at least 4 characters." });
  if (!/^[a-zA-Z0-9_.]+$/.test(String(username).trim()))
    return res.status(400).json({ error: "Username: letters, numbers, dots and underscores only." });

  const db = getDb();
  const cleanId   = String(student_id).trim().toUpperCase();
  const cleanUser = String(username).trim().toLowerCase();
  const role      = type === "staff" ? "staff" : "student";

  const existingMember = db.prepare("SELECT id FROM members WHERE student_id = ? COLLATE NOCASE").get(cleanId);
  if (existingMember) {
    const hasAccount = db.prepare("SELECT id FROM users WHERE member_id = ?").get(existingMember.id);
    if (hasAccount)
      return res.status(400).json({ error: "That School ID is already registered. Please log in instead." });
    db.prepare("DELETE FROM members WHERE id = ?").run(existingMember.id);
  }

  if (db.prepare("SELECT id FROM users WHERE username = ? COLLATE NOCASE").get(cleanUser))
    return res.status(400).json({ error: "That username is already taken. Please choose another." });

  try {
    db.exec("BEGIN");
    const r = db.prepare(
      "INSERT INTO members (student_id, name, grade, contact, type, status) VALUES (?,?,?,?,?,'active')"
    ).run(cleanId, String(full_name).trim(), String(grade || "").trim(), String(contact).trim(), role);
    db.prepare("INSERT INTO users (username, password, role, member_id) VALUES (?,?,?,?)")
      .run(cleanUser, String(password), role, r.lastInsertRowid);
    db.exec("COMMIT");
    res.status(201).json({ ok: true, username: cleanUser });
  } catch (err) {
    try { db.exec("ROLLBACK"); } catch (_) {}
    console.error("Register error:", err.message);
    res.status(500).json({ error: "Registration failed. Please try again." });
  }
});

router.get("/accounts", requireAdmin, (req, res) => {
  const rows = getDb().prepare(`
    SELECT u.id, u.username, u.role, u.is_active, u.created_at,
           m.name, m.student_id, m.grade, m.type AS member_type
    FROM users u
    LEFT JOIN members m ON m.id = u.member_id
    ORDER BY CASE u.role WHEN 'admin' THEN 0 WHEN 'staff' THEN 1 ELSE 2 END, m.name
  `).all();
  res.json(rows);
});

router.post("/accounts", requireAdmin, (req, res) => {
  const { username, password, role, member_id } = req.body || {};
  if (!username?.trim() || !password || !role)
    return res.status(400).json({ error: "Username, password and role are required." });
  if (String(password).length < 4)
    return res.status(400).json({ error: "Password must be at least 4 characters." });
  try {
    const r = getDb().prepare("INSERT INTO users (username, password, role, member_id) VALUES (?,?,?,?)")
      .run(username.trim().toLowerCase(), String(password), role, member_id || null);
    res.status(201).json({ ok: true, id: r.lastInsertRowid });
  } catch (e) {
    if (e.message?.includes("UNIQUE")) return res.status(400).json({ error: "Username already exists." });
    throw e;
  }
});

router.patch("/accounts/:id/password", requireAuth, (req, res) => {
  const targetId = parseInt(req.params.id);
  if (req.session.role !== "admin" && req.session.userId !== targetId)
    return res.status(403).json({ error: "You can only change your own password." });
  const { password } = req.body || {};
  if (!password || String(password).length < 4)
    return res.status(400).json({ error: "Password must be at least 4 characters." });
  getDb().prepare("UPDATE users SET password = ? WHERE id = ?").run(String(password), targetId);
  res.json({ ok: true });
});

router.patch("/accounts/:id/toggle", requireAdmin, (req, res) => {
  if (parseInt(req.params.id) === 1)
    return res.status(400).json({ error: "Cannot deactivate the admin account." });
  const db = getDb();
  const user = db.prepare("SELECT is_active FROM users WHERE id = ?").get(req.params.id);
  if (!user) return res.status(404).json({ error: "Account not found." });
  db.prepare("UPDATE users SET is_active = ? WHERE id = ?").run(user.is_active ? 0 : 1, req.params.id);
  res.json({ ok: true, is_active: !user.is_active });
});

router.delete("/accounts/:id", requireAdmin, (req, res) => {
  if (parseInt(req.params.id) === 1)
    return res.status(400).json({ error: "Cannot delete the admin account." });
  getDb().prepare("DELETE FROM users WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
