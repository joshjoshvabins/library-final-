const express = require("express");
const { getDb } = require("../db");
const router = express.Router();

function requireAuth(req, res, next) {
  if (req.session?.loggedIn) return next();
  res.status(401).json({ error: "Unauthorized" });
}
function requireAdmin(req, res, next) {
  if (req.session?.loggedIn && req.session.role === "admin") return next();
  res.status(403).json({ error: "Admin only" });
}

router.get("/", requireAuth, (req, res) => {
  const { search, type } = req.query;
  let sql = `
    SELECT m.*, COUNT(CASE WHEN l.status='active' THEN 1 END) AS active_loans,
           COUNT(l.id) AS total_loans
    FROM members m
    LEFT JOIN loans l ON l.member_id = m.id
    WHERE 1=1
  `;
  const params = [];
  if (search) {
    sql += " AND (m.name LIKE ? OR m.student_id LIKE ? OR m.grade LIKE ?)";
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (type) { sql += " AND m.type = ?"; params.push(type); }
  sql += " GROUP BY m.id ORDER BY m.type DESC, m.name ASC";
  res.json(getDb().prepare(sql).all(...params));
});

router.get("/:id", requireAuth, (req, res) => {
  const m = getDb().prepare("SELECT * FROM members WHERE id = ?").get(req.params.id);
  if (!m) return res.status(404).json({ error: "Member not found." });
  res.json(m);
});

router.post("/", requireAdmin, (req, res) => {
  const { student_id, name, grade, contact, type } = req.body || {};
  if (!student_id?.trim()) return res.status(400).json({ error: "School ID is required." });
  if (!name?.trim()) return res.status(400).json({ error: "Name is required." });
  try {
    const r = getDb().prepare("INSERT INTO members (student_id, name, grade, contact, type) VALUES (?,?,?,?,?)")
      .run(student_id.trim().toUpperCase(), name.trim(), grade?.trim() || "", contact?.trim() || "", type || "student");
    res.status(201).json(getDb().prepare("SELECT * FROM members WHERE id = ?").get(r.lastInsertRowid));
  } catch (e) {
    if (e.message?.includes("UNIQUE")) return res.status(400).json({ error: "That School ID already exists." });
    throw e;
  }
});

router.put("/:id", requireAdmin, (req, res) => {
  const db = getDb();
  const m = db.prepare("SELECT * FROM members WHERE id = ?").get(req.params.id);
  if (!m) return res.status(404).json({ error: "Member not found." });
  const { student_id, name, grade, contact, type, status } = req.body || {};
  try {
    db.prepare("UPDATE members SET student_id=?,name=?,grade=?,contact=?,type=?,status=? WHERE id=?")
      .run(student_id ?? m.student_id, name ?? m.name, grade ?? m.grade,
           contact ?? m.contact, type ?? m.type, status ?? m.status, req.params.id);
    res.json(db.prepare("SELECT * FROM members WHERE id = ?").get(req.params.id));
  } catch (e) {
    if (e.message?.includes("UNIQUE")) return res.status(400).json({ error: "That School ID already exists." });
    throw e;
  }
});

router.delete("/:id", requireAdmin, (req, res) => {
  const db = getDb();
  const active = db.prepare("SELECT COUNT(*) AS c FROM loans WHERE member_id = ? AND status = 'active'").get(req.params.id).c;
  if (active > 0) return res.status(400).json({ error: `Cannot delete — this member has ${active} active loan(s).` });
  db.prepare("DELETE FROM members WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
