import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// VITE_API_URL is set at build time for production deployments.
// Leave empty for local dev — Vite's proxy handles /api → localhost:5000.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/api": {
        target: "http://localhost:5000",
        changeOrigin: true,
        secure: false,
      },
    },
  },
  build: {
    outDir: "dist",
    emptyOutDir: true,
  },
});
