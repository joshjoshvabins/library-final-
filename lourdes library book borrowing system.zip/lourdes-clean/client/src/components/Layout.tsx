import { NavLink, Outlet, useNavigate } from "react-router-dom";
import {
  LayoutDashboard, BookOpen, Users, ArrowLeftRight,
  LogOut, Menu, X, BookMarked, UserCog, ClipboardList,
} from "lucide-react";
import { useState } from "react";
import { useAuth } from "../lib/AuthContext";
import toast from "react-hot-toast";

const ADMIN_NAV = [
  { to: "/dashboard", label: "Dashboard",    Icon: LayoutDashboard },
  { to: "/loans",     label: "Loans",        Icon: ArrowLeftRight },
  { to: "/books",     label: "Books",        Icon: BookOpen },
  { to: "/members",   label: "Members",      Icon: Users },
  { to: "/accounts",  label: "Accounts",     Icon: UserCog },
];
const STUDENT_NAV = [
  { to: "/my-loans", label: "My Transactions", Icon: ClipboardList },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const isAdmin = user?.role === "admin";
  const NAV = isAdmin ? ADMIN_NAV : STUDENT_NAV;

  const doLogout = async () => {
    await logout();
    toast.success("Logged out successfully");
    navigate("/login");
  };

  const roleBadge = (role?: string) => {
    if (role === "admin")  return "bg-amber-400/20 text-amber-200 border border-amber-400/30";
    if (role === "staff")  return "bg-emerald-400/20 text-emerald-200 border border-emerald-400/30";
    return "bg-primary-400/20 text-primary-200 border border-primary-400/30";
  };

  const SidebarContent = ({ onNav }: { onNav?(): void }) => (
    <div className="flex flex-col h-full">
      {/* Brand */}
      <div className="px-4 py-5 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-11 h-11 rounded-full bg-white p-0.5 shrink-0 shadow-lg ring-2 ring-white/20">
            <img src="/logo.png" alt="OLLC" className="w-full h-full object-contain rounded-full"
              onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <div className="min-w-0">
            <p className="text-white font-bold text-xs leading-tight">Our Lady of Lourdes</p>
            <p className="text-primary-300 text-xs">Library System</p>
          </div>
        </div>
      </div>

      {/* User info */}
      <div className="px-4 py-3 bg-black/10 border-b border-white/10">
        <div className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-bold mb-1 ${roleBadge(user?.role)}`}>
          {user?.role?.toUpperCase()}
        </div>
        <p className="text-white font-semibold text-sm leading-tight truncate">{user?.name}</p>
        {user?.student_id && <p className="text-primary-300 text-xs font-mono mt-0.5">{user.student_id}</p>}
        {user?.grade && <p className="text-primary-400 text-xs truncate">{user.grade}</p>}
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto">
        {NAV.map(({ to, label, Icon }) => (
          <NavLink key={to} to={to} onClick={onNav}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ${
                isActive
                  ? "bg-white text-primary-700 shadow-md font-bold"
                  : "text-primary-100 hover:bg-white/10 hover:text-white"
              }`}
          >
            <Icon size={18} className="shrink-0" />{label}
          </NavLink>
        ))}
      </nav>

      {/* Logout */}
      <div className="px-3 py-3 border-t border-white/10">
        <button onClick={doLogout}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium text-primary-100 hover:bg-red-500/80 hover:text-white transition-all duration-150">
          <LogOut size={18} />Sign Out
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-64 bg-primary-700 shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar */}
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <aside className="relative w-64 h-full bg-primary-700 flex flex-col shadow-2xl">
            <button className="absolute top-4 right-4 text-white/70 hover:text-white z-10 p-1 rounded-lg hover:bg-white/10"
              onClick={() => setOpen(false)}><X size={20} /></button>
            <SidebarContent onNav={() => setOpen(false)} />
          </aside>
        </div>
      )}

      {/* Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile header */}
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 bg-primary-700 text-white shrink-0 shadow-md">
          <button onClick={() => setOpen(true)} className="p-1 rounded-lg hover:bg-white/10"><Menu size={22} /></button>
          <div className="w-8 h-8 rounded-full bg-white p-0.5"><img src="/logo.png" alt="" className="w-full h-full object-contain rounded-full" /></div>
          <span className="font-bold text-sm">OLLC Library</span>
          <span className={`ml-auto text-xs font-bold px-2 py-0.5 rounded-full ${roleBadge(user?.role)}`}>
            {user?.role?.toUpperCase()}
          </span>
        </header>
        <main className="flex-1 overflow-y-auto p-4 lg:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
