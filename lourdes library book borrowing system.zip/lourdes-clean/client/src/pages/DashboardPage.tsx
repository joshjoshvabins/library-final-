import { useEffect, useState } from "react";
import {
  BookOpen, Users, BookMarked, AlertTriangle,
  TrendingUp, Hash, BookCheck, BarChart3,
} from "lucide-react";
import api from "../lib/api";
import { useNavigate } from "react-router-dom";

interface Stats {
  totalBooks: number; totalMembers: number; borrowed: number;
  overdue: number; totalFines: number; totalTxns: number; availableBooks: number;
}
interface OverdueLoan {
  id: number; transaction_id: string; book_title: string;
  member_name: string; member_student_id: string; member_contact: string;
  due_date: string; computed_fine: number;
}

function StatCard({ label, value, sub, Icon, iconBg, trend }: {
  label: string; value: string | number; sub?: string;
  Icon: React.ElementType; iconBg: string; trend?: "up" | "down" | "neutral";
}) {
  return (
    <div className="stat-card cursor-default">
      <div>
        <p className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">{label}</p>
        <p className="text-3xl font-black text-gray-900">{value}</p>
        {sub && <p className="text-xs text-gray-400 mt-1">{sub}</p>}
      </div>
      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${iconBg}`}>
        <Icon size={22} className="text-white" />
      </div>
    </div>
  );
}

export default function DashboardPage() {
  const [stats,   setStats]   = useState<Stats | null>(null);
  const [overdue, setOverdue] = useState<OverdueLoan[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    Promise.all([
      api.get("/loans/stats/dashboard"),
      api.get("/loans?status=overdue"),
    ]).then(([s, o]) => {
      setStats(s.data);
      setOverdue(o.data);
    }).finally(() => setLoading(false));
  }, []);

  const daysLate = (due: string) => {
    const d = Math.floor((Date.now() - new Date(due).getTime()) / 86400000);
    return d > 0 ? d : 0;
  };

  if (loading) return (
    <div className="flex items-center justify-center h-64">
      <div className="w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin" />
    </div>
  );

  const CARDS = stats ? [
    { label: "Total Book Copies", value: stats.totalBooks,    sub: `${stats.availableBooks} available`, Icon: BookOpen,      iconBg: "bg-primary-600" },
    { label: "Active Members",    value: stats.totalMembers,  sub: "students & staff",                 Icon: Users,         iconBg: "bg-indigo-500" },
    { label: "Currently Borrowed",value: stats.borrowed,      sub: "books out now",                    Icon: BookMarked,    iconBg: "bg-amber-500" },
    { label: "Overdue",           value: stats.overdue,       sub: "need immediate return",            Icon: AlertTriangle, iconBg: stats.overdue > 0 ? "bg-red-500" : "bg-gray-400" },
    { label: "Total Transactions",value: stats.totalTxns,     sub: "all time",                         Icon: Hash,          iconBg: "bg-slate-500" },
    { label: "Fines Collected",   value: `₱${(stats.totalFines||0).toLocaleString()}`, sub: "from late returns", Icon: TrendingUp, iconBg: "bg-emerald-600" },
  ] : [];

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-sub">{new Date().toLocaleDateString("en-PH", { weekday:"long", year:"numeric", month:"long", day:"numeric" })}</p>
        </div>
        <button className="btn-primary btn-sm" onClick={() => navigate("/loans")}>
          <BookMarked size={14} />New Transaction
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
        {CARDS.map(c => <StatCard key={c.label} {...c} />)}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Overdue table */}
        <div className="card overflow-hidden lg:col-span-2">
          <div className={`px-5 py-3.5 border-b flex items-center gap-2 ${overdue.length > 0 ? "bg-red-50 border-red-100" : "bg-gray-50 border-gray-100"}`}>
            <AlertTriangle size={15} className={overdue.length > 0 ? "text-red-500" : "text-gray-400"} />
            <h2 className={`font-bold text-sm ${overdue.length > 0 ? "text-red-700" : "text-gray-600"}`}>
              Overdue Books
              <span className={`ml-2 px-2 py-0.5 rounded-full text-xs ${overdue.length > 0 ? "bg-red-100 text-red-700" : "bg-gray-200 text-gray-600"}`}>
                {overdue.length}
              </span>
            </h2>
          </div>
          {overdue.length === 0 ? (
            <div className="px-5 py-10 text-center">
              <BookCheck size={32} className="text-emerald-300 mx-auto mb-2" />
              <p className="text-gray-400 text-sm font-medium">All books are on time!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="tbl">
                <thead><tr>
                  <th>TXN ID</th><th>Book</th><th>Member</th>
                  <th>Due</th><th>Days Late</th><th>Fine</th>
                </tr></thead>
                <tbody>
                  {overdue.map(l => (
                    <tr key={l.id} className="tbl-overdue">
                      <td><span className="font-mono text-xs font-bold text-red-600">{l.transaction_id}</span></td>
                      <td className="max-w-[140px]"><p className="font-semibold text-gray-900 text-xs truncate">{l.book_title}</p></td>
                      <td>
                        <p className="font-semibold text-sm">{l.member_name}</p>
                        <p className="text-xs text-gray-400 font-mono">{l.member_student_id}</p>
                      </td>
                      <td className="text-xs font-bold text-red-600">{l.due_date}</td>
                      <td><span className="badge-red">{daysLate(l.due_date)}d</span></td>
                      <td className="font-bold text-red-600">₱{Number(l.computed_fine||0).toFixed(0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Quick info panel */}
        <div className="space-y-4">
          <div className="card p-5">
            <h3 className="font-bold text-gray-700 text-sm mb-3 flex items-center gap-2">
              <BarChart3 size={15} className="text-primary-600" />Quick Summary
            </h3>
            {stats && [
              { label: "Books Available",   value: stats.availableBooks,  color: "text-emerald-600" },
              { label: "Books Out",         value: stats.borrowed,         color: "text-amber-600" },
              { label: "Overdue Right Now", value: stats.overdue,          color: "text-red-600" },
            ].map(r => (
              <div key={r.label} className="flex justify-between items-center py-2 border-b border-gray-50 last:border-0">
                <span className="text-sm text-gray-500">{r.label}</span>
                <span className={`font-bold text-lg ${r.color}`}>{r.value}</span>
              </div>
            ))}
          </div>

          <div className="card p-5">
            <h3 className="font-bold text-gray-700 text-sm mb-3">Quick Actions</h3>
            <div className="space-y-2">
              {[
                { label: "Issue a Book", onClick: () => navigate("/loans"), color: "btn-primary" },
                { label: "View All Loans", onClick: () => navigate("/loans"), color: "btn-outline" },
                { label: "Manage Books", onClick: () => navigate("/books"), color: "btn-ghost border border-gray-200" },
              ].map(a => (
                <button key={a.label} onClick={a.onClick} className={`${a.color} w-full text-sm`}>{a.label}</button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
