import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, CheckCircle } from "lucide-react";
import api from "../lib/api";
import toast from "react-hot-toast";

type AccountType = "student" | "staff";

interface FormState {
  full_name:  string;
  student_id: string;
  grade:      string;
  contact:    string;
  type:       AccountType;
  username:   string;
  password:   string;
  confirm:    string;
}

const EMPTY: FormState = {
  full_name: "", student_id: "", grade: "", contact: "",
  type: "student", username: "", password: "", confirm: "",
};

export default function RegisterPage() {
  const navigate = useNavigate();

  const [form,    setForm]    = useState<FormState>(EMPTY);
  const [showPw,  setShowPw]  = useState(false);
  const [error,   setError]   = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [createdUser, setCreatedUser] = useState("");

  const set = (key: keyof FormState, value: string) => {
    setForm(f => ({ ...f, [key]: value }));
    setError("");
  };

  const pwMatch = form.confirm.length > 0 && form.password === form.confirm;

  const validate = (): string => {
    if (!form.full_name.trim())   return "Full name is required.";
    if (!form.student_id.trim())  return "School ID is required.";
    if (!form.contact.trim())     return "Contact number is required.";
    if (!form.username.trim())    return "Username is required.";
    if (!/^[a-zA-Z0-9_.]+$/.test(form.username.trim()))
      return "Username can only have letters, numbers, dots and underscores.";
    if (!form.password)           return "Password is required.";
    if (form.password.length < 4) return "Password must be at least 4 characters.";
    if (form.password !== form.confirm) return "Passwords do not match.";
    return "";
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const err = validate();
    if (err) return setError(err);

    setLoading(true);
    setError("");
    try {
      const res = await api.post("/auth/register", {
        full_name:  form.full_name.trim(),
        student_id: form.student_id.trim(),
        grade:      form.grade.trim(),
        contact:    form.contact.trim(),
        type:       form.type,
        username:   form.username.trim().toLowerCase(),
        password:   form.password,
      });
      setCreatedUser(res.data.username);
      setSuccess(true);
    } catch (err: any) {
      setError(err.response?.data?.error || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  // ── Success screen ─────────────────────────────────────────────────────────
  if (success) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-primary-800 to-primary-600 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-8 text-center">
          <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle size={34} className="text-emerald-500" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Account Created!</h2>
          <p className="text-gray-500 text-sm mb-1">Welcome, <strong>{form.full_name}</strong>!</p>
          <p className="text-gray-400 text-sm mb-6">
            You can now sign in with your username and password.
          </p>

          <div className="bg-gray-50 rounded-xl px-5 py-4 mb-6 text-sm text-left space-y-1.5">
            <div className="flex justify-between">
              <span className="text-gray-500">Username:</span>
              <span className="font-mono font-bold text-gray-900">{createdUser}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">School ID:</span>
              <span className="font-mono text-gray-700">{form.student_id.toUpperCase()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">Type:</span>
              <span className="capitalize text-gray-700">{form.type}</span>
            </div>
          </div>

          <button
            className="btn-primary w-full py-3"
            onClick={() => navigate("/login")}
          >
            Go to Sign In →
          </button>
        </div>
      </div>
    );
  }

  // ── Registration form ──────────────────────────────────────────────────────
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-800 to-primary-600 flex items-center justify-center p-4 py-10">
      <div className="w-full max-w-lg">

        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">

          {/* Header */}
          <div className="bg-primary-700 px-8 py-6 flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-white p-1 shrink-0">
              <img src="/logo.png" alt="OLLC"
                className="w-full h-full object-contain rounded-full"
                onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
            </div>
            <div>
              <h1 className="text-white font-bold text-xl">Create Account</h1>
              <p className="text-primary-200 text-sm">Our Lady of Lourdes Library System</p>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="px-8 py-7 space-y-5">

            {/* Error */}
            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3 font-medium">
                ⚠ {error}
              </div>
            )}

            {/* ── Personal Info ── */}
            <div>
              <p className="text-xs font-bold text-primary-600 uppercase tracking-widest mb-3 pb-2 border-b border-gray-100">
                Personal Information
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="label">Full Name <span className="text-red-500">*</span></label>
                  <input className="input" placeholder="e.g. Maria Santos"
                    value={form.full_name} onChange={e => set("full_name", e.target.value)} autoFocus />
                </div>
                <div>
                  <label className="label">School ID <span className="text-red-500">*</span></label>
                  <input className="input font-mono" placeholder="e.g. 2024-00123"
                    value={form.student_id} onChange={e => set("student_id", e.target.value)} />
                </div>
                <div>
                  <label className="label">Contact Number <span className="text-red-500">*</span></label>
                  <input className="input" placeholder="e.g. 09XX XXX XXXX"
                    value={form.contact} onChange={e => set("contact", e.target.value)} />
                </div>
                <div className="sm:col-span-2">
                  <label className="label">Grade &amp; Section <span className="text-gray-400 font-normal text-xs">(leave blank if staff)</span></label>
                  <input className="input" placeholder="e.g. Grade 10 - St. Bernadette"
                    value={form.grade} onChange={e => set("grade", e.target.value)} />
                </div>
              </div>
            </div>

            {/* ── Account Type ── */}
            <div>
              <p className="text-xs font-bold text-primary-600 uppercase tracking-widest mb-3 pb-2 border-b border-gray-100">
                Account Type
              </p>
              <div className="flex gap-3">
                {(["student", "staff"] as AccountType[]).map(t => (
                  <button
                    key={t}
                    type="button"
                    onClick={() => set("type", t)}
                    className={`flex-1 py-2.5 rounded-xl border-2 font-semibold text-sm capitalize transition-all ${
                      form.type === t
                        ? "border-primary-600 bg-primary-600 text-white"
                        : "border-gray-200 text-gray-500 hover:border-primary-300"
                    }`}
                  >
                    {t === "student" ? "🎓 Student" : "👔 Staff"}
                  </button>
                ))}
              </div>
            </div>

            {/* ── Login Credentials ── */}
            <div>
              <p className="text-xs font-bold text-primary-600 uppercase tracking-widest mb-3 pb-2 border-b border-gray-100">
                Login Credentials
              </p>
              <div className="space-y-3">
                <div>
                  <label className="label">Username <span className="text-red-500">*</span></label>
                  <input className="input font-mono" placeholder="Choose a username (no spaces)"
                    value={form.username} onChange={e => set("username", e.target.value)}
                    autoComplete="username" />
                  <p className="text-xs text-gray-400 mt-1">Letters, numbers, dots and underscores only</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="label">Password <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <input
                        type={showPw ? "text" : "password"}
                        className="input pr-10"
                        placeholder="Min. 4 characters"
                        value={form.password}
                        onChange={e => set("password", e.target.value)}
                        autoComplete="new-password"
                      />
                      <button type="button" onClick={() => setShowPw(!showPw)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600" tabIndex={-1}>
                        {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
                      </button>
                    </div>
                  </div>
                  <div>
                    <label className="label">Confirm Password <span className="text-red-500">*</span></label>
                    <div className="relative">
                      <input
                        type={showPw ? "text" : "password"}
                        className={`input pr-10 ${
                          form.confirm.length > 0
                            ? pwMatch
                              ? "border-emerald-400 focus:ring-emerald-400"
                              : "border-red-400 focus:ring-red-400"
                            : ""
                        }`}
                        placeholder="Re-enter password"
                        value={form.confirm}
                        onChange={e => set("confirm", e.target.value)}
                        autoComplete="new-password"
                      />
                      {form.confirm.length > 0 && (
                        <span className="absolute right-3 top-1/2 -translate-y-1/2">
                          {pwMatch
                            ? <CheckCircle size={14} className="text-emerald-500" />
                            : <span className="text-red-500 text-xs font-bold">✗</span>}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="btn-primary w-full py-3 text-base mt-2"
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                  Creating Account…
                </span>
              ) : "Create Account"}
            </button>

            <p className="text-center text-sm text-gray-500">
              Already have an account?{" "}
              <Link to="/login" className="text-primary-600 font-bold hover:underline">
                Sign in →
              </Link>
            </p>

          </form>
        </div>

        <p className="text-center text-primary-300 text-xs mt-4">
          © {new Date().getFullYear()} Our Lady of Lourdes College — Valenzuela City
        </p>
      </div>
    </div>
  );
}
