import { useEffect, useState, useCallback } from "react";
import {
  Plus, Search, RotateCcw, AlertTriangle, Clock,
  CheckCircle, Hash, Eye, BookMarked,
} from "lucide-react";
import api from "../lib/api";
import Modal from "../components/Modal";
import toast from "react-hot-toast";

interface Loan {
  id:number; transaction_id:string;
  book_id:number; book_title:string; book_author:string; book_isbn:string;
  member_id_num:number; member_student_id:string; member_name:string;
  member_grade:string; member_type:string; member_contact:string;
  borrow_date:string; due_date:string; return_date:string|null;
  fine:number; computed_fine:number; status:string; is_overdue:number;
  processed_by:string; notes:string;
}
interface Book   { id:number; title:string; author:string; isbn:string; available_copies:number; genre:string; }
interface Member { id:number; student_id:string; name:string; grade:string; type:string; status:string; }

const addDays = (n:number) => {
  const d = new Date(); d.setDate(d.getDate()+n); return d.toISOString().split("T")[0];
};
const daysLate = (due:string) => Math.max(0, Math.floor((Date.now()-new Date(due).getTime())/86400000));
const peso = (v:number) => `₱${Number(v||0).toFixed(2)}`;
const tomorrow = () => addDays(1);

const TAB_OPTS = [
  { key:"active",   label:"Active" },
  { key:"overdue",  label:"Overdue" },
  { key:"returned", label:"Returned" },
  { key:"all",      label:"All" },
] as const;
type TabKey = typeof TAB_OPTS[number]["key"];

export default function LoansPage() {
  const [loans,   setLoans]   = useState<Loan[]>([]);
  const [books,   setBooks]   = useState<Book[]>([]);
  const [members, setMembers] = useState<Member[]>([]);
  const [search,  setSearch]  = useState("");
  const [tab,     setTab]     = useState<TabKey>("active");
  const [modal,   setModal]   = useState<"issue"|"return"|"view"|null>(null);
  const [sel,     setSel]     = useState<Loan|null>(null);
  const [form,    setForm]    = useState({ book_id:"", member_id:"", due_date:addDays(14), notes:"" });
  const [busy,    setBusy]    = useState(false);
  const [counts,  setCounts]  = useState<Record<string,number>>({});

  const loadLoans = useCallback(() => {
    const params: Record<string,string> = {};
    if (tab !== "all") params.status = tab;
    if (search) params.search = search;
    api.get("/loans", { params }).then(r => setLoans(r.data));
  }, [tab, search]);

  useEffect(() => { loadLoans(); }, [loadLoans]);

  useEffect(() => {
    api.get("/books").then(r => setBooks(r.data));
    api.get("/members").then(r => setMembers(r.data));
    // Load counts for each tab
    Promise.all(
      TAB_OPTS.filter(t => t.key !== "all").map(t =>
        api.get("/loans", { params:{ status:t.key }}).then(r => ({ key:t.key, count:r.data.length }))
      )
    ).then(results => {
      const c: Record<string,number> = {};
      results.forEach(r => { c[r.key] = r.count; });
      setCounts(c);
    });
  }, []);

  const close = () => { setModal(null); setSel(null); };

  const openIssue = () => { setForm({ book_id:"", member_id:"", due_date:addDays(14), notes:"" }); setModal("issue"); };
  const openReturn = (l:Loan) => { setSel(l); setModal("return"); };
  const openView   = (l:Loan) => { setSel(l); setModal("view"); };

  const issueLoan = async () => {
    if (!form.book_id)  return toast.error("Please select a book");
    if (!form.member_id) return toast.error("Please select a member");
    if (!form.due_date)  return toast.error("Please set a due date");
    setBusy(true);
    try {
      const r = await api.post("/loans", { book_id:+form.book_id, member_id:+form.member_id, due_date:form.due_date, notes:form.notes });
      toast.success(`✅ Issued! ${r.data.transaction_id}`);
      close(); loadLoans();
      api.get("/books").then(r => setBooks(r.data));
    } catch (e:any) { toast.error(e.response?.data?.error || "Error issuing book"); }
    finally { setBusy(false); }
  };

  const returnBook = async () => {
    if (!sel) return;
    setBusy(true);
    try {
      const r = await api.patch(`/loans/${sel.id}/return`);
      const fine = r.data.computed_fine ?? r.data.fine ?? 0;
      toast.success(fine > 0 ? `Returned! Fine: ${peso(fine)}` : "Returned on time! No fine.");
      close(); loadLoans();
      api.get("/books").then(r => setBooks(r.data));
    } catch (e:any) { toast.error(e.response?.data?.error || "Error processing return"); }
    finally { setBusy(false); }
  };

  const availBooks   = books.filter(b => b.available_copies > 0);
  const activeMembers = members.filter(m => m.status === "active");

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Borrowing Transactions</h1>
          <p className="page-sub">Issue books, process returns, view history</p>
        </div>
        <button className="btn-primary" onClick={openIssue}><Plus size={16}/>New Transaction</button>
      </div>

      {/* Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center gap-3 mb-5">
        <div className="flex bg-white border border-gray-200 rounded-xl p-1 gap-0.5 shadow-sm">
          {TAB_OPTS.map(t => (
            <button key={t.key} onClick={() => setTab(t.key)}
              className={`px-3 py-2 text-xs font-bold rounded-lg transition-all flex items-center gap-1.5 ${
                tab===t.key ? "bg-primary-600 text-white shadow-sm" : "text-gray-500 hover:text-gray-800 hover:bg-gray-50"
              }`}>
              {t.label}
              {t.key !== "all" && counts[t.key] !== undefined && (
                <span className={`px-1.5 py-0.5 rounded-full text-xs ${tab===t.key?"bg-white/20 text-white":"bg-gray-200 text-gray-600"}`}>
                  {counts[t.key]}
                </span>
              )}
            </button>
          ))}
        </div>
        <div className="relative flex-1 max-w-xs">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
          <input className="input pl-9 text-sm" placeholder="Search TXN, book or member…"
            value={search} onChange={e => setSearch(e.target.value)}/>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead><tr>
              <th>TXN ID</th><th>Book</th><th>Member</th><th>Borrowed</th>
              <th>Due Date</th><th>Returned</th><th>Fine</th><th>Status</th><th></th>
            </tr></thead>
            <tbody>
              {loans.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-14 text-gray-400">
                  <BookMarked size={32} className="mx-auto mb-2 text-gray-300"/>
                  No {tab !== "all" ? tab : ""} transactions found
                </td></tr>
              ) : loans.map(l => {
                const ov = l.status==="active" && !!l.is_overdue;
                return (
                  <tr key={l.id} className={ov?"tbl-overdue":""}>
                    <td>
                      <button onClick={() => openView(l)}
                        className="font-mono text-xs font-bold text-primary-600 hover:text-primary-800 hover:underline">
                        {l.transaction_id}
                      </button>
                    </td>
                    <td>
                      <p className="font-bold text-sm text-gray-900 max-w-[160px] truncate">{l.book_title}</p>
                      <p className="text-xs text-gray-400">{l.book_author}</p>
                    </td>
                    <td>
                      <p className="font-semibold text-sm">{l.member_name}</p>
                      <p className="text-xs font-mono text-gray-400">{l.member_student_id}</p>
                    </td>
                    <td className="text-xs text-gray-500">{l.borrow_date}</td>
                    <td>
                      <span className={`text-xs font-bold ${ov?"text-red-600":"text-gray-700"}`}>
                        {l.due_date}
                        {ov&&<span className="block text-red-400 font-normal">{daysLate(l.due_date)}d overdue</span>}
                      </span>
                    </td>
                    <td className="text-xs text-gray-400">{l.return_date||"—"}</td>
                    <td className={`font-bold text-sm ${l.computed_fine>0?"text-red-600":"text-gray-300"}`}>
                      {l.computed_fine>0?peso(l.computed_fine):"—"}
                    </td>
                    <td>
                      {l.status==="active"
                        ?ov?<span className="badge-red"><AlertTriangle size={10}/>Overdue</span>
                           :<span className="badge-yellow"><Clock size={10}/>Active</span>
                        :<span className="badge-green"><CheckCircle size={10}/>Returned</span>}
                    </td>
                    <td>
                      <div className="flex gap-1 justify-end">
                        <button onClick={()=>openView(l)} className="btn btn-ghost btn-sm" title="View details"><Eye size={13}/></button>
                        {l.status==="active"&&<button onClick={()=>openReturn(l)} className="btn-success btn btn-sm"><RotateCcw size={13}/>Return</button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Issue Modal */}
      {modal==="issue"&&(
        <Modal title="New Borrowing Transaction" onClose={close} size="lg">
          <div className="space-y-4">
            <div className="bg-primary-50 border border-primary-200 rounded-xl px-4 py-3 flex items-center gap-3">
              <Hash size={18} className="text-primary-500 shrink-0"/>
              <div>
                <p className="text-xs text-primary-500 font-semibold">Transaction ID assigned automatically</p>
                <p className="font-bold text-primary-700 font-mono text-sm">e.g. TXN-00015</p>
              </div>
            </div>

            <div>
              <label className="label">Select Book <span className="text-red-500">*</span></label>
              <select className="input" value={form.book_id} onChange={e=>setForm({...form,book_id:e.target.value})}>
                <option value="">— Choose an available book —</option>
                {availBooks.map(b=>(
                  <option key={b.id} value={b.id}>
                    [{b.genre||"No genre"}] {b.title} — {b.author} ({b.available_copies} left)
                  </option>
                ))}
              </select>
              {availBooks.length===0&&<p className="field-hint text-red-500">⚠ No books are currently available</p>}
            </div>

            <div>
              <label className="label">Select Member <span className="text-red-500">*</span></label>
              <select className="input" value={form.member_id} onChange={e=>setForm({...form,member_id:e.target.value})}>
                <option value="">— Choose a member —</option>
                <optgroup label="── Students ──">
                  {activeMembers.filter(m=>m.type==="student").map(m=>(
                    <option key={m.id} value={m.id}>{m.student_id} — {m.name} ({m.grade})</option>
                  ))}
                </optgroup>
                <optgroup label="── Staff ──">
                  {activeMembers.filter(m=>m.type==="staff").map(m=>(
                    <option key={m.id} value={m.id}>{m.student_id} — {m.name}</option>
                  ))}
                </optgroup>
              </select>
            </div>

            <div>
              <label className="label">Due Date <span className="text-red-500">*</span></label>
              <input type="date" className="input" value={form.due_date}
                min={tomorrow()}
                onChange={e=>setForm({...form,due_date:e.target.value})}/>
              <div className="flex gap-2 mt-2">
                {[7,14,21,30].map(d=>(
                  <button key={d} type="button" onClick={()=>setForm({...form,due_date:addDays(d)})}
                    className={`text-xs px-3 py-1.5 rounded-lg border font-semibold transition-all ${
                      form.due_date===addDays(d)
                        ?"border-primary-600 bg-primary-600 text-white"
                        :"border-gray-200 text-gray-500 hover:border-primary-400 hover:text-primary-600"
                    }`}>{d} days</button>
                ))}
              </div>
            </div>

            <div>
              <label className="label">Notes <span className="text-gray-400 font-normal">(optional)</span></label>
              <textarea className="input resize-none" rows={2} value={form.notes}
                onChange={e=>setForm({...form,notes:e.target.value})} placeholder="Any additional notes…"/>
            </div>

            <div className="bg-amber-50 border border-amber-200 rounded-xl px-4 py-2.5 text-xs text-amber-800 font-medium">
              📌 Fine policy: <strong>₱10 per day</strong> overdue after the due date.
            </div>

            <div className="flex gap-3 justify-end pt-1">
              <button className="btn-outline" onClick={close}>Cancel</button>
              <button className="btn-primary" onClick={issueLoan} disabled={busy}>
                {busy?<><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin"/>Issuing…</>:"Confirm Issue"}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Return Modal */}
      {modal==="return"&&sel&&(
        <Modal title="Process Book Return" onClose={close} size="sm">
          <div className="space-y-3">
            <div className="bg-gray-50 rounded-2xl p-4 space-y-2.5 text-sm border border-gray-100">
              {[
                ["Transaction ID", <span className="font-mono font-bold text-primary-700">{sel.transaction_id}</span>],
                ["Book",           <span className="font-semibold text-right max-w-[180px] leading-tight">{sel.book_title}</span>],
                ["Member",         <span className="font-semibold">{sel.member_name}</span>],
                ["School ID",      <span className="font-mono text-xs">{sel.member_student_id}</span>],
                ["Borrowed",       sel.borrow_date],
                ["Due Date",       <span className={sel.is_overdue?"text-red-600 font-bold":""}>{sel.due_date}</span>],
              ].map(([k,v])=>(
                <div key={String(k)} className="flex justify-between items-center">
                  <span className="text-gray-400">{k}</span>
                  <span className="text-gray-900">{v as React.ReactNode}</span>
                </div>
              ))}
              <div className="border-t border-gray-200 pt-2.5 mt-1">
                {sel.is_overdue?(
                  <>
                    <div className="flex justify-between items-center">
                      <span className="text-red-600 font-bold">Fine Due:</span>
                      <span className="text-red-600 font-black text-xl">{peso(sel.computed_fine)}</span>
                    </div>
                    <p className="text-xs text-red-400 mt-0.5">{daysLate(sel.due_date)} day(s) × ₱10/day</p>
                  </>
                ):(
                  <p className="text-emerald-600 font-bold text-sm flex items-center gap-1.5">
                    <CheckCircle size={15}/>Returned on time — no fine!
                  </p>
                )}
              </div>
            </div>
            <div className="flex gap-3 justify-end">
              <button className="btn-outline" onClick={close}>Cancel</button>
              <button className="btn-success" onClick={returnBook} disabled={busy}>
                {busy?"Processing…":"Confirm Return"}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* View Detail Modal */}
      {modal==="view"&&sel&&(
        <Modal title={`Transaction Details`} onClose={close} size="sm">
          <div className="space-y-2 text-sm">
            {[
              ["Transaction ID",  <span className="font-mono font-black text-primary-700 text-base">{sel.transaction_id}</span>],
              ["Book ID",         <span className="font-mono text-gray-600">BK-{String(sel.book_id).padStart(4,"0")}</span>],
              ["Book Title",      sel.book_title],
              ["Author",          sel.book_author],
              ["ISBN",            sel.book_isbn||"—"],
              ["Member ID",       <span className="font-mono font-bold">{sel.member_student_id}</span>],
              ["Member Name",     sel.member_name],
              ["Grade/Section",   sel.member_grade||"—"],
              ["Contact",         sel.member_contact||"—"],
              ["Date Borrowed",   sel.borrow_date],
              ["Due Date",        <span className={sel.is_overdue?"text-red-600 font-bold":""}>{sel.due_date}</span>],
              ["Date Returned",   sel.return_date||"—"],
              ["Fine",            <span className={sel.computed_fine>0?"text-red-600 font-bold":"text-gray-400"}>{peso(sel.computed_fine)}</span>],
              ["Status",          sel.status==="active"&&sel.is_overdue?<span className="badge-red">OVERDUE</span>:sel.status==="active"?<span className="badge-yellow">ACTIVE</span>:<span className="badge-green">RETURNED</span>],
              ["Notes",           sel.notes||"—"],
              ["Processed By",    sel.processed_by],
            ].map(([k,v])=>(
              <div key={String(k)} className="flex justify-between items-start gap-4 py-1.5 border-b border-gray-50 last:border-0">
                <span className="text-gray-400 shrink-0 text-xs font-semibold uppercase tracking-wide">{k}</span>
                <span className="font-medium text-gray-900 text-right">{v as React.ReactNode}</span>
              </div>
            ))}
          </div>
          <div className="flex justify-end pt-4">
            <button className="btn-outline" onClick={close}>Close</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
