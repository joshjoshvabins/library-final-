import { useEffect, useState, useCallback } from "react";
import { Plus, Search, Pencil, Trash2, BookOpen, Filter } from "lucide-react";
import api from "../lib/api";
import Modal from "../components/Modal";
import toast from "react-hot-toast";

interface Book {
  id: number; title: string; author: string; isbn: string;
  genre: string; total_copies: number; available_copies: number;
  borrowed_copies: number; is_available: number;
}
const EMPTY = { title:"", author:"", isbn:"", genre:"", total_copies:1 };

export default function BooksPage() {
  const [books,   setBooks]   = useState<Book[]>([]);
  const [genres,  setGenres]  = useState<string[]>([]);
  const [search,  setSearch]  = useState("");
  const [genre,   setGenre]   = useState("");
  const [modal,   setModal]   = useState<"add"|"edit"|"delete"|null>(null);
  const [sel,     setSel]     = useState<Book|null>(null);
  const [form,    setForm]    = useState({...EMPTY});
  const [busy,    setBusy]    = useState(false);

  const load = useCallback(() => {
    api.get("/books", { params: { search: search||undefined, genre: genre||undefined }}).then(r => setBooks(r.data));
  }, [search, genre]);

  useEffect(() => { load(); }, [load]);
  useEffect(() => { api.get("/books/genres").then(r => setGenres(r.data)); }, []);

  const openAdd  = () => { setForm({...EMPTY}); setSel(null); setModal("add"); };
  const openEdit = (b: Book) => { setSel(b); setForm({ title:b.title, author:b.author, isbn:b.isbn||"", genre:b.genre||"", total_copies:b.total_copies }); setModal("edit"); };
  const openDel  = (b: Book) => { setSel(b); setModal("delete"); };
  const close    = () => { setModal(null); setSel(null); };

  const validate = () => {
    if (!form.title.trim()) { toast.error("Title is required"); return false; }
    if (!form.author.trim()) { toast.error("Author is required"); return false; }
    if (form.total_copies < 1) { toast.error("At least 1 copy required"); return false; }
    return true;
  };

  const save = async () => {
    if (!validate()) return;
    setBusy(true);
    try {
      if (modal === "add") { await api.post("/books", form); toast.success("Book added successfully!"); }
      else { await api.put(`/books/${sel!.id}`, form); toast.success("Book updated!"); }
      close(); load();
    } catch (e: any) { toast.error(e.response?.data?.error || "Failed to save book."); }
    finally { setBusy(false); }
  };

  const del = async () => {
    setBusy(true);
    try { await api.delete(`/books/${sel!.id}`); toast.success("Book deleted."); close(); load(); }
    catch (e: any) { toast.error(e.response?.data?.error || "Cannot delete."); }
    finally { setBusy(false); }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Books</h1>
          <p className="page-sub">{books.length} book title{books.length !== 1 ? "s" : ""} in collection</p>
        </div>
        <button className="btn-primary" onClick={openAdd}><Plus size={16} />Add Book</button>
      </div>

      {/* Filters */}
      <div className="flex gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input className="input pl-9" placeholder="Search title, author or ISBN…"
            value={search} onChange={e => setSearch(e.target.value)} />
        </div>
        <div className="flex items-center gap-2">
          <Filter size={14} className="text-gray-400" />
          <select className="input w-44" value={genre} onChange={e => setGenre(e.target.value)}>
            <option value="">All Genres</option>
            {genres.map(g => <option key={g} value={g}>{g}</option>)}
          </select>
        </div>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead><tr>
              <th>Title & Author</th><th>ISBN</th><th>Genre</th>
              <th>Total</th><th>Available</th><th>Borrowed</th><th>Status</th><th></th>
            </tr></thead>
            <tbody>
              {books.length === 0 ? (
                <tr><td colSpan={8} className="text-center py-14 text-gray-400">
                  <BookOpen size={32} className="mx-auto mb-2 text-gray-300" />
                  {search || genre ? "No books match your search" : "No books yet — add one!"}
                </td></tr>
              ) : books.map(b => (
                <tr key={b.id}>
                  <td>
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-primary-100 flex items-center justify-center shrink-0">
                        <BookOpen size={16} className="text-primary-600" />
                      </div>
                      <div>
                        <p className="font-bold text-gray-900 leading-tight">{b.title}</p>
                        <p className="text-xs text-gray-400 mt-0.5">{b.author}</p>
                      </div>
                    </div>
                  </td>
                  <td><span className="font-mono text-xs text-gray-500">{b.isbn || "—"}</span></td>
                  <td>{b.genre ? <span className="badge-blue">{b.genre}</span> : <span className="text-gray-300">—</span>}</td>
                  <td className="font-bold text-gray-700">{b.total_copies}</td>
                  <td><span className={b.available_copies > 0 ? "badge-green" : "badge-red"}>{b.available_copies}</span></td>
                  <td>{b.borrowed_copies > 0 ? <span className="badge-yellow">{b.borrowed_copies}</span> : <span className="text-gray-300 text-sm">0</span>}</td>
                  <td>
                    {b.is_available
                      ? <span className="badge-green">Available</span>
                      : <span className="badge-red">All Out</span>}
                  </td>
                  <td>
                    <div className="flex gap-1 justify-end">
                      <button onClick={() => openEdit(b)} className="btn btn-ghost btn-sm" title="Edit"><Pencil size={14} /></button>
                      <button onClick={() => openDel(b)}  className="btn btn-ghost btn-sm hover:text-red-600" title="Delete"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {(modal === "add" || modal === "edit") && (
        <Modal title={modal === "add" ? "Add New Book" : "Edit Book"} onClose={close}>
          <div className="space-y-4">
            <div>
              <label className="label">Title <span className="text-red-500">*</span></label>
              <input className="input" value={form.title}
                onChange={e => setForm({...form, title: e.target.value})} placeholder="e.g. Noli Me Tangere" autoFocus />
            </div>
            <div>
              <label className="label">Author <span className="text-red-500">*</span></label>
              <input className="input" value={form.author}
                onChange={e => setForm({...form, author: e.target.value})} placeholder="e.g. José Rizal" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">ISBN</label>
                <input className="input font-mono" value={form.isbn}
                  onChange={e => setForm({...form, isbn: e.target.value})} placeholder="978-…" />
              </div>
              <div>
                <label className="label">Genre</label>
                <input className="input" list="genre-list" value={form.genre}
                  onChange={e => setForm({...form, genre: e.target.value})} placeholder="e.g. Fiction" />
                <datalist id="genre-list">{genres.map(g => <option key={g} value={g} />)}</datalist>
              </div>
              <div>
                <label className="label">Total Copies <span className="text-red-500">*</span></label>
                <input type="number" min={1} className="input" value={form.total_copies}
                  onChange={e => setForm({...form, total_copies: Math.max(1, +e.target.value)})} />
              </div>
            </div>
            {modal === "edit" && sel && (
              <p className="text-xs text-gray-400 bg-gray-50 rounded-lg px-3 py-2">
                Currently borrowed: <strong>{sel.borrowed_copies}</strong> cop{sel.borrowed_copies !== 1 ? "ies" : "y"}.
                Total copies cannot be set below this.
              </p>
            )}
            <div className="flex gap-3 justify-end pt-2">
              <button className="btn-outline" onClick={close}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={busy}>
                {busy ? "Saving…" : modal === "add" ? "Add Book" : "Save Changes"}
              </button>
            </div>
          </div>
        </Modal>
      )}

      {/* Delete Modal */}
      {modal === "delete" && sel && (
        <Modal title="Delete Book" onClose={close} size="sm">
          <p className="text-gray-600 mb-2">Delete this book permanently?</p>
          <div className="bg-gray-50 rounded-xl px-4 py-3 mb-4">
            <p className="font-bold text-gray-900">{sel.title}</p>
            <p className="text-sm text-gray-500">{sel.author}</p>
          </div>
          <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-5">
            ⚠ Books with active loans cannot be deleted.
          </p>
          <div className="flex gap-3 justify-end">
            <button className="btn-outline" onClick={close}>Cancel</button>
            <button className="btn-danger" onClick={del} disabled={busy}>{busy ? "Deleting…" : "Delete Book"}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
