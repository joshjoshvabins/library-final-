import { useEffect, useState, useCallback } from "react";
import { Plus, Search, Pencil, Trash2, GraduationCap, Users, UserPlus, CheckCircle, XCircle } from "lucide-react";
import api from "../lib/api";
import Modal from "../components/Modal";
import toast from "react-hot-toast";

interface Member { id:number; student_id:string; name:string; grade:string; contact:string; type:string; status:string; active_loans:number; total_loans:number; }
interface Account { id:number; username:string; student_id:string; }
const EMPTY = { student_id:"", name:"", grade:"", contact:"", type:"student", status:"active" };

export default function MembersPage() {
  const [members,  setMembers]  = useState<Member[]>([]);
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [search,   setSearch]   = useState("");
  const [typeF,    setTypeF]    = useState("");
  const [modal,    setModal]    = useState<"add"|"edit"|"delete"|"newAccount"|null>(null);
  const [sel,      setSel]      = useState<Member|null>(null);
  const [form,     setForm]     = useState({...EMPTY});
  const [accForm,  setAccForm]  = useState({ username:"", password:"" });
  const [busy,     setBusy]     = useState(false);

  const loadAll = useCallback(() => {
    api.get("/members", { params:{ search:search||undefined, type:typeF||undefined }}).then(r => setMembers(r.data));
    api.get("/auth/accounts").then(r => setAccounts(r.data));
  }, [search, typeF]);

  useEffect(() => { loadAll(); }, [loadAll]);

  const hasAccount = (m: Member) => accounts.some(a => a.student_id?.toUpperCase() === m.student_id?.toUpperCase());
  const close = () => { setModal(null); setSel(null); };

  const openAdd  = () => { setForm({...EMPTY}); setSel(null); setModal("add"); };
  const openEdit = (m: Member) => { setSel(m); setForm({ student_id:m.student_id, name:m.name, grade:m.grade, contact:m.contact, type:m.type, status:m.status }); setModal("edit"); };
  const openDel  = (m: Member) => { setSel(m); setModal("delete"); };
  const openAcct = (m: Member) => {
    setSel(m);
    setAccForm({ username: m.name.toLowerCase().replace(/\s+/g,".").replace(/[^a-z0-9.]/g,""), password: "" });
    setModal("newAccount");
  };

  const save = async () => {
    if (!form.student_id.trim()) return toast.error("School ID is required");
    if (!form.name.trim())       return toast.error("Name is required");
    setBusy(true);
    try {
      if (modal === "add") { await api.post("/members", form); toast.success("Member added!"); }
      else                 { await api.put(`/members/${sel!.id}`, form); toast.success("Member updated!"); }
      close(); loadAll();
    } catch (e:any) { toast.error(e.response?.data?.error || "Error saving member"); }
    finally { setBusy(false); }
  };

  const del = async () => {
    setBusy(true);
    try { await api.delete(`/members/${sel!.id}`); toast.success("Member removed."); close(); loadAll(); }
    catch (e:any) { toast.error(e.response?.data?.error || "Cannot delete."); }
    finally { setBusy(false); }
  };

  const createAccount = async () => {
    if (!accForm.username.trim())  return toast.error("Username is required");
    if (accForm.password.length < 4) return toast.error("Password must be at least 4 characters");
    if (!/^[a-zA-Z0-9_]+$/.test(accForm.username)) return toast.error("Username: letters, numbers, underscores only");
    setBusy(true);
    try {
      await api.post("/auth/accounts", { username:accForm.username.trim(), password:accForm.password, role:sel!.type, member_id:sel!.id });
      toast.success(`Account created! Username: ${accForm.username}`);
      close(); loadAll();
    } catch (e:any) { toast.error(e.response?.data?.error || "Error creating account"); }
    finally { setBusy(false); }
  };

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Members</h1>
          <p className="page-sub">{members.length} member{members.length !== 1?"s":""} registered</p>
        </div>
        <button className="btn-primary" onClick={openAdd}><Plus size={16}/>Add Member</button>
      </div>

      {/* Info banner */}
      <div className="bg-primary-50 border border-primary-200 rounded-xl px-5 py-3 mb-5 text-sm text-primary-800">
        <strong>Tip:</strong> Adding a member here does <u>not</u> create a login account.
        Look for <strong>❌ No login</strong> rows and click <strong>👤+</strong> to create their account.
      </div>

      <div className="flex gap-3 mb-5 flex-wrap">
        <div className="relative flex-1 min-w-[200px] max-w-sm">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
          <input className="input pl-9" placeholder="Search name, ID or grade…" value={search} onChange={e=>setSearch(e.target.value)}/>
        </div>
        <select className="input w-36" value={typeF} onChange={e=>setTypeF(e.target.value)}>
          <option value="">All Types</option>
          <option value="student">Students</option>
          <option value="staff">Staff</option>
        </select>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead><tr>
              <th>Name</th><th>School ID</th><th>Type</th><th>Grade/Section</th>
              <th>Contact</th><th>Status</th><th>Loans</th><th>Login?</th><th></th>
            </tr></thead>
            <tbody>
              {members.length === 0 ? (
                <tr><td colSpan={9} className="text-center py-14 text-gray-400">
                  <Users size={32} className="mx-auto mb-2 text-gray-300"/>No members found
                </td></tr>
              ) : members.map(m => {
                const acct = hasAccount(m);
                return (
                  <tr key={m.id}>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 rounded-full bg-primary-100 flex items-center justify-center shrink-0">
                          {m.type==="staff"?<Users size={14} className="text-primary-600"/>:<GraduationCap size={14} className="text-primary-600"/>}
                        </div>
                        <span className="font-bold text-gray-900">{m.name}</span>
                      </div>
                    </td>
                    <td><span className="font-mono text-xs font-bold text-gray-600">{m.student_id}</span></td>
                    <td><span className={m.type==="staff"?"badge-green":"badge-blue"}>{m.type}</span></td>
                    <td className="text-sm text-gray-500">{m.grade||"—"}</td>
                    <td className="text-sm text-gray-500">{m.contact||"—"}</td>
                    <td><span className={m.status==="active"?"badge-green":"badge-gray"}>{m.status}</span></td>
                    <td>
                      {m.active_loans>0
                        ?<span className="badge-yellow">{m.active_loans} active</span>
                        :<span className="text-gray-300 text-xs">{m.total_loans} total</span>}
                    </td>
                    <td>
                      {acct
                        ?<span className="flex items-center gap-1 text-xs text-emerald-600 font-bold"><CheckCircle size={13}/>Yes</span>
                        :<span className="flex items-center gap-1 text-xs text-red-400 font-bold"><XCircle size={13}/>No login</span>}
                    </td>
                    <td>
                      <div className="flex gap-1 justify-end">
                        {!acct&&<button onClick={()=>openAcct(m)} className="btn btn-ghost btn-sm text-primary-500 hover:text-primary-700" title="Create login account"><UserPlus size={14}/></button>}
                        <button onClick={()=>openEdit(m)} className="btn btn-ghost btn-sm" title="Edit"><Pencil size={14}/></button>
                        <button onClick={()=>openDel(m)}  className="btn btn-ghost btn-sm hover:text-red-600" title="Delete"><Trash2 size={14}/></button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit */}
      {(modal==="add"||modal==="edit")&&(
        <Modal title={modal==="add"?"Add New Member":"Edit Member"} onClose={close}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">School / Staff ID <span className="text-red-500">*</span></label>
                <input className="input font-mono" value={form.student_id} onChange={e=>setForm({...form,student_id:e.target.value})} placeholder="e.g. 2024-0009" autoFocus/>
              </div>
              <div>
                <label className="label">Type</label>
                <select className="input" value={form.type} onChange={e=>setForm({...form,type:e.target.value})}>
                  <option value="student">Student</option>
                  <option value="staff">Staff</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="label">Full Name <span className="text-red-500">*</span></label>
                <input className="input" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. Maria Santos"/>
              </div>
              <div>
                <label className="label">Grade & Section</label>
                <input className="input" value={form.grade} onChange={e=>setForm({...form,grade:e.target.value})} placeholder="e.g. Grade 10 - St. Joseph"/>
              </div>
              <div>
                <label className="label">Contact</label>
                <input className="input" value={form.contact} onChange={e=>setForm({...form,contact:e.target.value})} placeholder="09XXXXXXXXX"/>
              </div>
              <div>
                <label className="label">Status</label>
                <select className="input" value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>
                  <option value="active">Active</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>
            </div>
            {modal==="add"&&<p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">💡 After adding, use the 👤+ button to create their login account.</p>}
            <div className="flex gap-3 justify-end pt-2">
              <button className="btn-outline" onClick={close}>Cancel</button>
              <button className="btn-primary" onClick={save} disabled={busy}>{busy?"Saving…":modal==="add"?"Add Member":"Save Changes"}</button>
            </div>
          </div>
        </Modal>
      )}

      {/* Create Account */}
      {modal==="newAccount"&&sel&&(
        <Modal title="Create Login Account" onClose={close} size="sm">
          <div className="bg-primary-50 border border-primary-200 rounded-xl px-4 py-3 mb-4">
            <p className="text-xs text-primary-500 font-semibold mb-1">Creating account for:</p>
            <p className="font-bold text-primary-800 text-base">{sel.name}</p>
            <p className="text-xs text-primary-500 font-mono">{sel.student_id} · {sel.grade||sel.type}</p>
          </div>
          <div className="space-y-3">
            <div>
              <label className="label">Username <span className="text-red-500">*</span></label>
              <input className="input font-mono" value={accForm.username} onChange={e=>setAccForm({...accForm,username:e.target.value})} placeholder="e.g. maria.santos" autoFocus/>
              <p className="field-hint">Letters, numbers, underscores only. Will be used to sign in.</p>
            </div>
            <div>
              <label className="label">Password <span className="text-red-500">*</span></label>
              <input type="password" className="input" value={accForm.password} onChange={e=>setAccForm({...accForm,password:e.target.value})} placeholder="Minimum 4 characters"/>
              <p className="field-hint">They can change this after logging in.</p>
            </div>
          </div>
          <div className="flex gap-3 justify-end pt-4">
            <button className="btn-outline" onClick={close}>Cancel</button>
            <button className="btn-primary" onClick={createAccount} disabled={busy}>{busy?"Creating…":"Create Account"}</button>
          </div>
        </Modal>
      )}

      {/* Delete */}
      {modal==="delete"&&sel&&(
        <Modal title="Remove Member" onClose={close} size="sm">
          <p className="text-gray-600 mb-2">Remove <strong>{sel.name}</strong> from the system?</p>
          <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 mb-5">⚠ Members with active loans cannot be removed.</p>
          <div className="flex gap-3 justify-end">
            <button className="btn-outline" onClick={close}>Cancel</button>
            <button className="btn-danger" onClick={del} disabled={busy}>{busy?"Removing…":"Remove"}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
