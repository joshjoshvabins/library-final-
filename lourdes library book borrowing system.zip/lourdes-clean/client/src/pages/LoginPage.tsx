import { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { Eye, EyeOff, BookMarked } from "lucide-react";
import { useAuth } from "../lib/AuthContext";
import toast from "react-hot-toast";

export default function LoginPage() {
  const { login, user } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const from = (location.state as any)?.from?.pathname;

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPw,   setShowPw]   = useState(false);
  const [error,    setError]    = useState("");
  const [loading,  setLoading]  = useState(false);

  // Already logged in → redirect
  if (user) {
    navigate(from || (user.role === "admin" ? "/dashboard" : "/my-loans"), { replace: true });
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!username.trim()) return setError("Please enter your username.");
    if (!password)        return setError("Please enter your password.");

    setLoading(true);
    try {
      await login(username.trim(), password);
      toast.success("Logged in!");
    } catch (err: any) {
      setError(err.response?.data?.error || "Login failed. Please check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-800 to-primary-600 flex items-center justify-center p-4">
      <div className="w-full max-w-sm">

        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">

          {/* ── Header ── */}
          <div className="bg-primary-700 px-8 py-8 flex flex-col items-center text-center">
            <div className="w-24 h-24 rounded-full bg-white p-1.5 shadow-lg mb-4">
              <img
                src="/logo.png"
                alt="Our Lady of Lourdes College"
                className="w-full h-full object-contain rounded-full"
                onError={e => {
                  const el = e.target as HTMLImageElement;
                  el.style.display = "none";
                  el.parentElement!.innerHTML = `<div class="w-full h-full flex items-center justify-center"><svg xmlns='http://www.w3.org/2000/svg' width='40' height='40' viewBox='0 0 24 24' fill='none' stroke='#2563eb' stroke-width='2'><path d='M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z'/><path d='M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z'/></svg></div>`;
                }}
              />
            </div>
            <h1 className="text-white font-bold text-lg leading-snug">
              Our Lady of Lourdes<br />Library System
            </h1>
            <p className="text-primary-200 text-xs mt-1 italic">
              Truth... Commitment... Excellence
            </p>
          </div>

          {/* ── Form ── */}
          <div className="px-8 py-7">

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-sm rounded-xl px-4 py-3 mb-5 font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="label">Username</label>
                <input
                  className="input"
                  placeholder="Enter your username"
                  value={username}
                  onChange={e => { setUsername(e.target.value); setError(""); }}
                  autoFocus
                  autoComplete="username"
                />
              </div>

              <div>
                <label className="label">Password</label>
                <div className="relative">
                  <input
                    type={showPw ? "text" : "password"}
                    className="input pr-10"
                    placeholder="Enter your password"
                    value={password}
                    onChange={e => { setPassword(e.target.value); setError(""); }}
                    autoComplete="current-password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPw(!showPw)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    tabIndex={-1}
                  >
                    {showPw ? <EyeOff size={16} /> : <Eye size={16} />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-3 text-base mt-2"
              >
                {loading ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                    Signing in…
                  </span>
                ) : "Sign In"}
              </button>
            </form>

            <p className="text-center text-sm text-gray-500 mt-6">
              No account yet?{" "}
              <Link to="/register" className="text-primary-600 font-bold hover:underline">
                Create account →
              </Link>
            </p>

          </div>
        </div>

        {/* Hint */}
        <div className="mt-4 bg-white/10 rounded-xl px-4 py-3 text-center text-primary-200 text-xs">
          <p className="font-semibold mb-1">Default admin login</p>
          <p>Username: <span className="font-mono font-bold text-white">admin</span></p>
          <p>Password: <span className="font-mono font-bold text-white">lourdes123</span></p>
        </div>

      </div>
    </div>
  );
}
