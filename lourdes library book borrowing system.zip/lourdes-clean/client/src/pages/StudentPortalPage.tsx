import { useEffect, useState, useCallback } from "react";
import {
  BookMarked, Clock, CheckCircle, AlertTriangle,
  Hash, KeyRound, UserX, BookOpen, Calendar,
} from "lucide-react";
import api from "../lib/api";
import { useAuth } from "../lib/AuthContext";
import Modal from "../components/Modal";
import toast from "react-hot-toast";

interface Loan {
  id:number; transaction_id:string;
  book_title:string; book_author:string;
  borrow_date:string; due_date:string; return_date:string|null;
  computed_fine:number; status:string; is_overdue:number;
}
interface Stats { active:number; overdue:number; total:number; fines:number; }

const daysLate = (due:string) => Math.max(0, Math.floor((Date.now()-new Date(due).getTime())/86400000));
const peso = (v:number) => `₱${Number(v||0).toFixed(2)}`;

const TABS = [
  { key:"active",   label:"Active" },
  { key:"returned", label:"Returned" },
  { key:"all",      label:"All History" },
] as const;
type TabKey = typeof TABS[number]["key"];

export default function StudentPortalPage() {
  const { user } = useAuth();
  const [loans,   setLoans]   = useState<Loan[]>([]);
  const [stats,   setStats]   = useState<Stats|null>(null);
  const [tab,     setTab]     = useState<TabKey>("active");
  const [loading, setLoading] = useState(true);
  const [pwModal, setPwModal] = useState(false);
  const [pw,      setPw]      = useState({ newPw:"", confirm:"" });
  const [busy,    setBusy]    = useState(false);
  const [showPw,  setShowPw]  = useState(false);

  const hasLinked = !!user?.member_id;

  const loadLoans = useCallback(() => {
    if (!hasLinked) { setLoading(false); return; }
    const params: Record<string,string> = {};
    if (tab !== "all") params.status = tab;
    api.get("/loans", { params })
      .then(r => setLoans(r.data))
      .catch(() => setLoans([]))
      .finally(() => setLoading(false));
  }, [tab, hasLinked]);

  useEffect(() => {
    if (!hasLinked) { setLoading(false); return; }
    api.get("/loans/stats/dashboard")
      .then(r => setStats(r.data))
      .catch(() => setStats({ active:0, overdue:0, total:0, fines:0 }));
  }, [hasLinked]);

  useEffect(() => { setLoading(true); loadLoans(); }, [loadLoans]);

  const changePw = async () => {
    if (!pw.newPw) return toast.error("Please enter a new password");
    if (pw.newPw !== pw.confirm) return toast.error("Passwords do not match");
    if (pw.newPw.length < 4)     return toast.error("Password must be at least 4 characters");
    setBusy(true);
    try {
      await api.patch(`/auth/accounts/${user!.id}/password`, { password:pw.newPw });
      toast.success("Password changed successfully!");
      setPwModal(false); setPw({ newPw:"", confirm:"" });
    } catch (e:any) { toast.error(e.response?.data?.error || "Error changing password"); }
    finally { setBusy(false); }
  };

  // No linked member
  if (!hasLinked) return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">My Library Account</h1>
          <p className="page-sub">Logged in as <strong className="font-mono">{user?.username}</strong></p>
        </div>
        <button className="btn-outline text-sm" onClick={() => setPwModal(true)}>
          <KeyRound size={14}/>Change Password
        </button>
      </div>
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="w-20 h-20 rounded-full bg-amber-100 flex items-center justify-center mb-5 shadow-inner">
          <UserX size={36} className="text-amber-500"/>
        </div>
        <h2 className="text-xl font-black text-gray-800 mb-2">Account Not Linked</h2>
        <p className="text-gray-500 max-w-sm text-sm leading-relaxed">
          Your login account isn't linked to a library member record yet.
          Please visit the library and ask the librarian to link your account,
          or contact them directly.
        </p>
        <div className="mt-6 bg-primary-50 border border-primary-200 rounded-xl px-5 py-3 text-sm text-primary-700 max-w-xs">
          <strong>Username:</strong> <span className="font-mono">{user?.username}</span><br/>
          <strong>Role:</strong> {user?.role}
        </div>
      </div>
      {pwModal && (
        <Modal title="Change Password" onClose={() => { setPwModal(false); setPw({ newPw:"", confirm:"" }); }} size="sm">
          <div className="space-y-3">
            <div>
              <label className="label">New Password</label>
              <input type={showPw?"text":"password"} className="input" value={pw.newPw}
                onChange={e=>setPw({...pw,newPw:e.target.value})} placeholder="Min 4 characters" autoFocus/>
            </div>
            <div>
              <label className="label">Confirm Password</label>
              <input type={showPw?"text":"password"} className="input" value={pw.confirm}
                onChange={e=>setPw({...pw,confirm:e.target.value})}/>
            </div>
            <label className="flex items-center gap-2 text-xs text-gray-500 cursor-pointer">
              <input type="checkbox" checked={showPw} onChange={e=>setShowPw(e.target.checked)} className="rounded"/>
              Show passwords
            </label>
            <div className="flex gap-3 justify-end pt-2">
              <button className="btn-outline" onClick={() => setPwModal(false)}>Cancel</button>
              <button className="btn-primary" onClick={changePw} disabled={busy}>{busy?"Saving…":"Change Password"}</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">My Transactions</h1>
          <p className="page-sub">
            {user?.name}
            {user?.student_id && <> · <span className="font-mono text-primary-600">{user.student_id}</span></>}
            {user?.grade && <> · {user.grade}</>}
          </p>
        </div>
        <button className="btn-outline text-sm" onClick={() => setPwModal(true)}>
          <KeyRound size={14}/>Change Password
        </button>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
          {[
            { label:"Currently Out",  value:stats.active,       color:"text-amber-600",   bg:"bg-amber-50 border-amber-100",   Icon:BookMarked },
            { label:"Overdue",        value:stats.overdue,      color:"text-red-600",     bg:stats.overdue>0?"bg-red-50 border-red-200":"bg-gray-50 border-gray-100", Icon:AlertTriangle },
            { label:"Total Borrowed", value:stats.total,        color:"text-primary-600", bg:"bg-primary-50 border-primary-100",Icon:Hash },
            { label:"Fines Paid",     value:peso(stats.fines),  color:"text-emerald-700", bg:"bg-emerald-50 border-emerald-100",Icon:CheckCircle },
          ].map(({ label, value, color, bg, Icon }) => (
            <div key={label} className={`card border p-4 flex items-center gap-3 ${bg}`}>
              <Icon size={22} className={`${color} shrink-0`}/>
              <div>
                <p className="text-xs text-gray-500 font-medium">{label}</p>
                <p className={`text-xl font-black ${color}`}>{value}</p>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Overdue warning */}
      {stats && stats.overdue > 0 && (
        <div className="bg-red-50 border-2 border-red-200 rounded-2xl px-5 py-4 mb-5 flex items-start gap-3">
          <AlertTriangle size={20} className="text-red-500 shrink-0 mt-0.5"/>
          <div>
            <p className="text-red-800 font-bold">You have {stats.overdue} overdue book{stats.overdue>1?"s":""}!</p>
            <p className="text-red-600 text-sm mt-0.5">Please return to the library immediately. Fine accumulates at ₱10 per day.</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex bg-white border border-gray-200 rounded-xl p-1 w-fit mb-5 shadow-sm">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-sm font-bold rounded-lg transition-all ${
              tab===t.key ? "bg-primary-600 text-white shadow-sm" : "text-gray-500 hover:text-gray-800"
            }`}>{t.label}</button>
        ))}
      </div>

      <div className="card overflow-hidden">
        {loading ? (
          <div className="py-14 flex flex-col items-center gap-3 text-gray-400">
            <div className="w-8 h-8 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin"/>
            <p className="text-sm">Loading your transactions…</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="tbl">
              <thead><tr>
                <th>Transaction ID</th><th>Book</th><th>Date Borrowed</th>
                <th>Due Date</th><th>Date Returned</th><th>Fine</th><th>Status</th>
              </tr></thead>
              <tbody>
                {loans.length === 0 ? (
                  <tr><td colSpan={7} className="text-center py-14">
                    <BookOpen size={32} className="mx-auto mb-2 text-gray-300"/>
                    <p className="text-gray-400 font-medium">
                      {tab==="active" ? "No active loans right now" : "No transactions found"}
                    </p>
                  </td></tr>
                ) : loans.map(l => {
                  const ov = l.status==="active" && !!l.is_overdue;
                  return (
                    <tr key={l.id} className={ov?"tbl-overdue":""}>
                      <td><span className="font-mono text-xs font-bold text-primary-700">{l.transaction_id}</span></td>
                      <td>
                        <p className="font-bold text-sm text-gray-900">{l.book_title}</p>
                        <p className="text-xs text-gray-400">{l.book_author}</p>
                      </td>
                      <td className="text-xs text-gray-500">
                        <div className="flex items-center gap-1"><Calendar size={11}/>{l.borrow_date}</div>
                      </td>
                      <td>
                        <span className={`text-xs font-bold ${ov?"text-red-600":"text-gray-700"}`}>
                          {l.due_date}
                          {ov&&<span className="block text-red-400 font-normal">{daysLate(l.due_date)}d overdue</span>}
                        </span>
                      </td>
                      <td className="text-xs text-gray-400">{l.return_date||"—"}</td>
                      <td className={`font-bold text-sm ${l.computed_fine>0?"text-red-600":"text-gray-300"}`}>
                        {l.computed_fine>0?peso(l.computed_fine):"—"}
                      </td>
                      <td>
                        {l.status==="active"
                          ?ov?<span className="badge-red"><AlertTriangle size={10}/>Overdue</span>
                             :<span className="badge-yellow"><Clock size={10}/>Active</span>
                          :<span className="badge-green"><CheckCircle size={10}/>Returned</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Change Password Modal */}
      {pwModal && (
        <Modal title="Change Password" onClose={() => { setPwModal(false); setPw({ newPw:"", confirm:"" }); }} size="sm">
          <div className="space-y-3">
            <div>
              <label className="label">New Password</label>
              <input type={showPw?"text":"password"} className="input" value={pw.newPw}
                onChange={e=>setPw({...pw,newPw:e.target.value})} placeholder="Min 4 characters" autoFocus/>
            </div>
            <div>
              <label className="label">Confirm New Password</label>
              <input type={showPw?"text":"password"} className="input" value={pw.confirm}
                onChange={e=>setPw({...pw,confirm:e.target.value})}/>
              {pw.confirm && pw.newPw !== pw.confirm && (
                <p className="text-xs text-red-500 mt-1">Passwords do not match</p>
              )}
              {pw.confirm && pw.newPw === pw.confirm && (
                <p className="text-xs text-emerald-600 mt-1 flex items-center gap-1"><CheckCircle size={11}/>Passwords match</p>
              )}
            </div>
            <label className="flex items-center gap-2 text-xs text-gray-500 cursor-pointer">
              <input type="checkbox" checked={showPw} onChange={e=>setShowPw(e.target.checked)} className="rounded"/>
              Show passwords
            </label>
            <div className="flex gap-3 justify-end pt-2">
              <button className="btn-outline" onClick={() => setPwModal(false)}>Cancel</button>
              <button className="btn-primary" onClick={changePw} disabled={busy || (!!pw.confirm && pw.newPw !== pw.confirm)}>
                {busy?"Saving…":"Change Password"}
              </button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
