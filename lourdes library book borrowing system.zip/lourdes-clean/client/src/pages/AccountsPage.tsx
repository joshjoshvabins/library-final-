import { useEffect, useState, useCallback } from "react";
import {
  Plus, Trash2, ShieldCheck, GraduationCap, Users,
  ToggleLeft, ToggleRight, KeyRound, Eye, EyeOff,
} from "lucide-react";
import api from "../lib/api";
import Modal from "../components/Modal";
import toast from "react-hot-toast";

interface Account {
  id:number; username:string; role:string; is_active:number; created_at:string;
  name:string; student_id:string; grade:string; member_type:string; contact:string;
}
interface Member { id:number; student_id:string; name:string; grade:string; type:string; }

export default function AccountsPage() {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const [members,  setMembers]  = useState<Member[]>([]);
  const [modal,    setModal]    = useState<"add"|"delete"|"password"|null>(null);
  const [sel,      setSel]      = useState<Account|null>(null);
  const [form,     setForm]     = useState({ username:"", password:"", role:"student", member_id:"" });
  const [newPw,    setNewPw]    = useState({ pw:"", confirm:"" });
  const [showPw,   setShowPw]   = useState(false);
  const [busy,     setBusy]     = useState(false);

  const loadAll = useCallback(() => {
    api.get("/auth/accounts").then(r => setAccounts(r.data));
    api.get("/members").then(r => setMembers(r.data));
  }, []);
  useEffect(() => { loadAll(); }, [loadAll]);

  const close = () => { setModal(null); setSel(null); setShowPw(false); };

  const unlinkedMembers = members.filter(m => !accounts.some(a => a.student_id?.toUpperCase() === m.student_id?.toUpperCase()));

  const createAccount = async () => {
    if (!form.username.trim()) return toast.error("Username is required");
    if (!form.password || form.password.length < 4) return toast.error("Password must be at least 4 characters");
    if (!/^[a-zA-Z0-9_]+$/.test(form.username)) return toast.error("Username: letters, numbers, underscores only");
    setBusy(true);
    try {
      await api.post("/auth/accounts", { username:form.username.trim(), password:form.password, role:form.role, member_id:form.member_id||null });
      toast.success("Account created!");
      close(); loadAll();
    } catch (e:any) { toast.error(e.response?.data?.error || "Error creating account"); }
    finally { setBusy(false); }
  };

  const deleteAccount = async () => {
    setBusy(true);
    try { await api.delete(`/auth/accounts/${sel!.id}`); toast.success("Account deleted"); close(); loadAll(); }
    catch (e:any) { toast.error(e.response?.data?.error || "Cannot delete"); }
    finally { setBusy(false); }
  };

  const toggleAccount = async (a: Account) => {
    try {
      await api.patch(`/auth/accounts/${a.id}/toggle`);
      toast.success(`Account ${a.is_active ? "deactivated" : "activated"}`);
      loadAll();
    } catch (e:any) { toast.error(e.response?.data?.error || "Error"); }
  };

  const changePassword = async () => {
    if (!newPw.pw || newPw.pw.length < 4) return toast.error("Password must be at least 4 characters");
    if (newPw.pw !== newPw.confirm) return toast.error("Passwords do not match");
    setBusy(true);
    try {
      await api.patch(`/auth/accounts/${sel!.id}/password`, { password: newPw.pw });
      toast.success("Password reset successfully!");
      close();
    } catch (e:any) { toast.error(e.response?.data?.error || "Error"); }
    finally { setBusy(false); }
  };

  const roleIcon  = (role:string) => role==="admin"?<ShieldCheck size={13} className="text-amber-600"/>:role==="staff"?<Users size={13} className="text-emerald-600"/>:<GraduationCap size={13} className="text-primary-600"/>;
  const roleColor = (role:string) => role==="admin"?"badge-yellow":role==="staff"?"badge-green":"badge-blue";

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">User Accounts</h1>
          <p className="page-sub">Manage login credentials for students and staff</p>
        </div>
        <button className="btn-primary" onClick={() => { setForm({username:"",password:"",role:"student",member_id:""}); setModal("add"); }}>
          <Plus size={16}/>Create Account
        </button>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="tbl">
            <thead><tr>
              <th>Username</th><th>Role</th><th>Name</th><th>School ID</th>
              <th>Grade</th><th>Status</th><th>Created</th><th></th>
            </tr></thead>
            <tbody>
              {accounts.map(a => (
                <tr key={a.id} className={!a.is_active ? "opacity-50" : ""}>
                  <td>
                    <div className="flex items-center gap-2">
                      {roleIcon(a.role)}
                      <span className="font-mono font-bold text-sm">{a.username}</span>
                    </div>
                  </td>
                  <td><span className={roleColor(a.role)}>{a.role}</span></td>
                  <td className="font-semibold text-gray-900">{a.name||"—"}</td>
                  <td className="font-mono text-xs text-gray-600">{a.student_id||"—"}</td>
                  <td className="text-sm text-gray-500 max-w-[140px] truncate">{a.grade||"—"}</td>
                  <td>
                    <span className={a.is_active?"badge-green":"badge-gray"}>
                      {a.is_active?"Active":"Inactive"}
                    </span>
                  </td>
                  <td className="text-xs text-gray-400">{new Date(a.created_at).toLocaleDateString("en-PH")}</td>
                  <td>
                    {a.id !== 1 && (
                      <div className="flex gap-1 justify-end">
                        <button onClick={() => { setSel(a); setNewPw({pw:"",confirm:""}); setModal("password"); }}
                          className="btn btn-ghost btn-sm" title="Reset password"><KeyRound size={13}/></button>
                        <button onClick={() => toggleAccount(a)}
                          className="btn btn-ghost btn-sm" title={a.is_active?"Deactivate":"Activate"}>
                          {a.is_active?<ToggleRight size={16} className="text-emerald-500"/>:<ToggleLeft size={16} className="text-gray-400"/>}
                        </button>
                        <button onClick={() => { setSel(a); setModal("delete"); }}
                          className="btn btn-ghost btn-sm hover:text-red-600" title="Delete"><Trash2 size={13}/></button>
                      </div>
                    )}
                    {a.id === 1 && <span className="text-xs text-gray-300 px-3">protected</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Create Modal */}
      {modal==="add"&&(
        <Modal title="Create User Account" onClose={close}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="label">Username <span className="text-red-500">*</span></label>
                <input className="input font-mono" value={form.username}
                  onChange={e=>setForm({...form,username:e.target.value})} placeholder="e.g. juan.delacruz" autoFocus/>
                <p className="field-hint">Letters, numbers, underscores</p>
              </div>
              <div>
                <label className="label">Password <span className="text-red-500">*</span></label>
                <div className="relative">
                  <input type={showPw?"text":"password"} className="input pr-8" value={form.password}
                    onChange={e=>setForm({...form,password:e.target.value})} placeholder="Min 4 chars"/>
                  <button type="button" onClick={()=>setShowPw(!showPw)} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">
                    {showPw?<EyeOff size={14}/>:<Eye size={14}/>}
                  </button>
                </div>
              </div>
              <div>
                <label className="label">Role</label>
                <select className="input" value={form.role} onChange={e=>setForm({...form,role:e.target.value})}>
                  <option value="student">Student</option>
                  <option value="staff">Staff</option>
                </select>
              </div>
              <div>
                <label className="label">Link to Member</label>
                <select className="input" value={form.member_id} onChange={e=>setForm({...form,member_id:e.target.value})}>
                  <option value="">— None / Skip —</option>
                  <optgroup label="Students">{unlinkedMembers.filter(m=>m.type==="student").map(m=><option key={m.id} value={m.id}>{m.student_id} — {m.name}</option>)}</optgroup>
                  <optgroup label="Staff">{unlinkedMembers.filter(m=>m.type==="staff").map(m=><option key={m.id} value={m.id}>{m.student_id} — {m.name}</option>)}</optgroup>
                </select>
              </div>
            </div>
            <p className="text-xs text-primary-700 bg-primary-50 border border-primary-200 rounded-lg px-3 py-2">
              💡 Linking allows the user to see their borrowing history in "My Transactions".
            </p>
            <div className="flex gap-3 justify-end pt-1">
              <button className="btn-outline" onClick={close}>Cancel</button>
              <button className="btn-primary" onClick={createAccount} disabled={busy}>{busy?"Creating…":"Create Account"}</button>
            </div>
          </div>
        </Modal>
      )}

      {/* Reset Password Modal */}
      {modal==="password"&&sel&&(
        <Modal title="Reset Password" onClose={close} size="sm">
          <p className="text-sm text-gray-600 mb-4">Set a new password for <strong className="font-mono">{sel.username}</strong></p>
          <div className="space-y-3">
            <div>
              <label className="label">New Password</label>
              <div className="relative">
                <input type={showPw?"text":"password"} className="input pr-8" value={newPw.pw}
                  onChange={e=>setNewPw({...newPw,pw:e.target.value})} placeholder="Min 4 characters" autoFocus/>
                <button type="button" onClick={()=>setShowPw(!showPw)} className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400">
                  {showPw?<EyeOff size={14}/>:<Eye size={14}/>}
                </button>
              </div>
            </div>
            <div>
              <label className="label">Confirm Password</label>
              <input type={showPw?"text":"password"} className="input" value={newPw.confirm}
                onChange={e=>setNewPw({...newPw,confirm:e.target.value})}/>
              {newPw.confirm&&newPw.pw!==newPw.confirm&&<p className="text-xs text-red-500 mt-1">Passwords don't match</p>}
            </div>
          </div>
          <div className="flex gap-3 justify-end pt-4">
            <button className="btn-outline" onClick={close}>Cancel</button>
            <button className="btn-primary" onClick={changePassword} disabled={busy||(!!(newPw.confirm)&&newPw.pw!==newPw.confirm)}>
              {busy?"Saving…":"Reset Password"}
            </button>
          </div>
        </Modal>
      )}

      {/* Delete Modal */}
      {modal==="delete"&&sel&&(
        <Modal title="Delete Account" onClose={close} size="sm">
          <p className="text-gray-600 mb-1">Delete this login account?</p>
          <p className="font-mono font-bold text-gray-900 text-lg mb-2">{sel.username}</p>
          <p className="text-xs text-gray-400 mb-5">The member record will NOT be deleted — only the login credentials.</p>
          <div className="flex gap-3 justify-end">
            <button className="btn-outline" onClick={close}>Cancel</button>
            <button className="btn-danger" onClick={deleteAccount} disabled={busy}>{busy?"Deleting…":"Delete"}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}
