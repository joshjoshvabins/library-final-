import React, { createContext, useContext, useEffect, useState } from "react";
import api from "./api";

export interface User {
  id: number; username: string;
  role: "admin" | "student" | "staff";
  name: string; student_id: string | null;
  grade: string | null; contact: string | null;
  member_id: number | null; member_type: string | null;
}

interface AuthCtx {
  user: User | null; loading: boolean;
  login(u: string, p: string): Promise<void>;
  logout(): Promise<void>;
  refresh(): Promise<void>;
}

const Ctx = createContext<AuthCtx | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser]       = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    try { const r = await api.get("/auth/me"); setUser(r.data.user); }
    catch { setUser(null); }
  };

  useEffect(() => { refresh().finally(() => setLoading(false)); }, []);

  const login = async (username: string, password: string) => {
    const r = await api.post("/auth/login", { username, password });
    setUser(r.data.user);
  };

  const logout = async () => {
    await api.post("/auth/logout").catch(() => {});
    setUser(null);
  };

  return <Ctx.Provider value={{ user, loading, login, logout, refresh }}>{children}</Ctx.Provider>;
}

export function useAuth() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useAuth outside AuthProvider");
  return c;
}
