import axios from "axios";

// In production (Vercel/Netlify), set VITE_API_URL to the Render backend URL.
// In dev, leave it empty — Vite proxy handles /api → localhost:5000.
const BASE = import.meta.env.VITE_API_URL
  ? `${import.meta.env.VITE_API_URL}/api`
  : "/api";

const api = axios.create({
  baseURL: BASE,
  withCredentials: true,
});

api.interceptors.response.use(
  (r) => r,
  (e) => {
    if (e.response?.status === 401 && window.location.pathname !== "/login")
      window.location.href = "/login";
    return Promise.reject(e);
  }
);

export default api;
