import React from "react";
import { Navigate, Route, Routes, useLocation } from "react-router-dom";
import { useAuth } from "./lib/AuthContext";
import Layout       from "./components/Layout";
import LoginPage    from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import DashboardPage from "./pages/DashboardPage";
import BooksPage    from "./pages/BooksPage";
import MembersPage  from "./pages/MembersPage";
import LoansPage    from "./pages/LoansPage";
import StudentPortalPage from "./pages/StudentPortalPage";
import AccountsPage from "./pages/AccountsPage";

function Spinner() {
  return (
    <div className="h-screen flex items-center justify-center bg-slate-50">
      <div className="flex flex-col items-center gap-3">
        <div className="w-10 h-10 border-4 border-primary-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-sm text-gray-400 font-medium">Loading…</p>
      </div>
    </div>
  );
}

function RequireAuth({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <Spinner />;
  if (!user)   return <Navigate to="/login" state={{ from: loc }} replace />;
  return <>{children}</>;
}

function RequireAdmin({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  if (loading) return <Spinner />;
  if (!user)   return <Navigate to="/login" replace />;
  if (user.role !== "admin") return <Navigate to="/my-loans" replace />;
  return <>{children}</>;
}

export default function App() {
  const { user } = useAuth();
  const isAdmin  = user?.role === "admin";

  return (
    <Routes>
      <Route path="/login"    element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />

      <Route path="/" element={<RequireAuth><Layout /></RequireAuth>}>
        <Route index element={<Navigate to={isAdmin ? "/dashboard" : "/my-loans"} replace />} />

        {/* Admin */}
        <Route path="dashboard" element={<RequireAdmin><DashboardPage /></RequireAdmin>} />
        <Route path="books"     element={<RequireAdmin><BooksPage /></RequireAdmin>} />
        <Route path="members"   element={<RequireAdmin><MembersPage /></RequireAdmin>} />
        <Route path="loans"     element={<RequireAdmin><LoansPage /></RequireAdmin>} />
        <Route path="accounts"  element={<RequireAdmin><AccountsPage /></RequireAdmin>} />

        {/* Student / Staff */}
        <Route path="my-loans"  element={<StudentPortalPage />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
