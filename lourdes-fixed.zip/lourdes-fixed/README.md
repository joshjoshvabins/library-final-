# 📚 Our Lady of Lourdes Library System
### *Truth... Commitment... Excellence*
**Our Lady of Lourdes College — Valenzuela City (Est. 1986)**

---

## 🖥️ Local Development (same as before)

### Requirements
- Node.js v22.5 or newer — check with `node -v`

```bash
# 1. Install all dependencies
npm run install:all

# 2. Terminal 1 — Start backend (port 5000)
cd server
npm run dev

# 3. Terminal 2 — Start frontend (port 5173)
cd client
npm run dev

# 4. Open browser
# http://localhost:5173
# Login: admin / lourdes123
```

---

## 🌍 Making It Public — 3 Options

### ⚡ OPTION A: ngrok (fastest — public URL in 5 minutes, no hosting needed)

**Best for:** presentations, demos, showing classmates without deploying.
**Limitation:** URL changes every time you restart ngrok (free tier). Data only exists on your laptop.

#### Step 1 — Install ngrok
Go to https://ngrok.com → Sign up (free) → Download ngrok for Windows.

Or install via terminal:
```bash
# Windows (using winget)
winget install ngrok

# Or download the .exe from https://ngrok.com/download and add to PATH
```

#### Step 2 — Set up ngrok auth token
After signing up at ngrok.com, copy your token from the dashboard:
```bash
ngrok config add-authtoken YOUR_TOKEN_HERE
```

#### Step 3 — Start your server
```bash
cd server
npm run dev
```
Server runs on port 5000.

#### Step 4 — Expose it with ngrok
Open a NEW terminal:
```bash
ngrok http 5000
```

You'll see output like:
```
Forwarding  https://abc123def456.ngrok-free.app → http://localhost:5000
```

#### Step 5 — Update CORS so the browser can connect
In `server/.env` (create if it doesn't exist):
```
CLIENT_URL=*
SESSION_SECRET=any_random_string_for_demo
NODE_ENV=development
```
Restart the server (`Ctrl+C` then `npm run dev` again).

#### Step 6 — Share the URL
Give anyone the ngrok URL: `https://abc123def456.ngrok-free.app`

⚠️ **Note:** The frontend still runs on YOUR laptop at localhost:5173.
If you want others to access the full frontend too, also run:
```bash
# Terminal 3
cd client
npm run dev
```
Then expose port 5173 with ANOTHER ngrok tunnel:
```bash
# Terminal 4
ngrok http 5173
```
Share the 5173 ngrok URL. Update `client/.env.local`:
```
VITE_API_URL=https://abc123def456.ngrok-free.app
```
Restart the client after that change.

---

### 🚀 OPTION B: Render.com (free, permanent URL — recommended for projects)

**Best for:** A real hosted version that stays online 24/7 (mostly).
**URL:** `https://lourdes-library.onrender.com` (you choose the name)
**Limitation:** Free tier sleeps after 15 min of inactivity — first load takes ~30 sec to wake up.
**Important:** SQLite data is WIPED on every redeploy (Render's disk is ephemeral on free tier). Use only for demos, not real library data.

#### Step 1 — Push to GitHub

```bash
# In your project root (lourdes-library folder):
git init
git add .
git commit -m "Initial commit - Our Lady of Lourdes Library System"
```

Go to https://github.com → New repository → name it `lourdes-library` → Create.

```bash
git remote add origin https://github.com/YOUR_USERNAME/lourdes-library.git
git branch -M main
git push -u origin main
```

#### Step 2 — Connect to Render

1. Go to https://render.com → Sign up with GitHub
2. Click **New +** → **Web Service**
3. Connect your GitHub repo
4. Fill in the settings:

| Field | Value |
|-------|-------|
| **Name** | `lourdes-library` |
| **Region** | Singapore (closest to PH) |
| **Runtime** | Node |
| **Build Command** | `npm install --prefix server && npm install --prefix client && npm run build --prefix client` |
| **Start Command** | `node --experimental-sqlite server/index.js` |
| **Plan** | Free |

#### Step 3 — Set Environment Variables
In Render → your service → **Environment** tab:

| Key | Value |
|-----|-------|
| `NODE_ENV` | `production` |
| `SESSION_SECRET` | (click "Generate" for a random value) |
| `CLIENT_URL` | *(leave blank — same service serves frontend)* |

#### Step 4 — Deploy
Click **Create Web Service**. Render will:
1. Pull your code from GitHub
2. Run the build command (installs deps + builds React)
3. Start the server

After ~3 minutes, your app is live at:
```
https://lourdes-library.onrender.com
```

#### Step 5 — Auto-deploy on push
Every `git push` to main will trigger a new deploy automatically.

---

### 🔧 OPTION C: Separate Deploy — Vercel (frontend) + Render (backend)

**Best for:** Faster frontend loads + more professional setup.
**Limitation:** Requires configuring CORS and env vars in two places.

#### Part 1 — Deploy backend to Render (API only)
Follow Option B steps above, but:
- Name it `lourdes-library-api`
- URL will be: `https://lourdes-library-api.onrender.com`
- Add env var: `CLIENT_URL=https://lourdes-library.vercel.app`

#### Part 2 — Deploy frontend to Vercel
1. Go to https://vercel.com → Import from GitHub
2. Select your repo
3. Set **Root Directory** to `client`
4. Add environment variable:
   ```
   VITE_API_URL = https://lourdes-library-api.onrender.com
   ```
5. Deploy — Vercel gives you: `https://lourdes-library.vercel.app`

#### Part 3 — Update backend CORS
In Render backend env vars:
```
CLIENT_URL=https://lourdes-library.vercel.app
```

---

## 🔑 Environment Variables Reference

### Server (`server/.env`)
```env
PORT=5000
SESSION_SECRET=your_long_random_secret_here
CLIENT_URL=http://localhost:5173
NODE_ENV=development
```

### Client (`client/.env.local`)
```env
# Only needed for Option C (separate frontend/backend)
VITE_API_URL=https://your-backend.onrender.com
```

---

## 🗄️ Database Schema

```sql
books      (id, title, author, isbn, genre, total_copies, available_copies)
members    (id, student_id, name, grade, contact, status)
loans      (id, book_id FK, member_id FK, borrow_date, due_date, return_date, fine, status)
```

Auto-seeded with 10 books and 8 members on first run.

---

## ⚠️ IMPORTANT WARNINGS

### 🔴 Security (READ BEFORE GOING PUBLIC)

1. **Change the password immediately.**
   The default `admin / lourdes123` is visible in this README and the source code.
   Update it in `server/routes/auth.js` before any real deployment.

2. **Set a strong SESSION_SECRET.**
   The default `INSECURE_CHANGE_ME` is not safe. Generate a real one:
   ```bash
   node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
   ```

3. **This is a demo/MVP login system.**
   Credentials are hardcoded. A real system should use a database-backed user table
   with proper hashed passwords.

4. **HTTPS is required for production cookies.**
   The server sets `secure: true` on cookies when `NODE_ENV=production`.
   Render, Vercel, and Railway all provide HTTPS automatically. ✅

### 🟡 SQLite on Free Hosting

- **Render free tier:** The filesystem is **ephemeral** — all data is wiped on every redeploy.
  This means the library database resets to seed data after each push.
  ✅ Fine for demos and presentations.
  ❌ Not for a real live library with real data.

- **Solution for persistent data:** Upgrade to Render's paid tier ($7/mo) with a persistent disk,
  OR switch to PostgreSQL (free on Render/Railway/Neon.tech).

### 🟢 For a Real School Deployment

If this will be used for actual library operations:
1. Change the admin password
2. Use a persistent database (PostgreSQL or paid Render disk)
3. Add SSL/HTTPS (automatic on Render/Vercel)
4. Consider backing up the database regularly

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Vite 5, Tailwind CSS v3 |
| Backend | Express.js + Node.js built-in SQLite (node:sqlite) |
| Auth | express-session (session cookie) |
| Hosting | Render.com (single service) or Vercel + Render |
| No compilation needed | Uses Node.js 22.5+ built-in SQLite |

---

## 📋 Deployment Comparison

| | ngrok | Render (single) | Vercel + Render |
|--|-------|-----------------|-----------------|
| Setup time | 5 min | 15 min | 25 min |
| Permanent URL | ❌ | ✅ | ✅ |
| Free | ✅ | ✅ | ✅ |
| Data persists | ✅ (local) | ❌ (resets on deploy) | ❌ |
| Custom domain | ❌ | ✅ (paid) | ✅ (paid) |
| Best for | Demos | Projects | Production-like |
