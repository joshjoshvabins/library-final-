"use strict";
const express = require("express");
const { getDb } = require("../db");
const router = express.Router();

function requireAuth(req, res, next) {
  if (req.session?.loggedIn) return next();
  res.status(401).json({ error: "Unauthorized" });
}
function requireAdmin(req, res, next) {
  if (req.session?.loggedIn && req.session.role === "admin") return next();
  res.status(403).json({ error: "Admin only" });
}

const BOOK_SELECT = `
  SELECT b.*,
    b.total_copies - b.available_copies AS borrowed_copies,
    CASE WHEN b.available_copies > 0 THEN 1 ELSE 0 END AS is_available
  FROM books b
`;

// GET /api/books?search=&genre=
router.get("/", requireAuth, (req, res) => {
  const { search, genre } = req.query;
  let sql = BOOK_SELECT + " WHERE 1=1";
  const params = [];
  if (search) {
    sql += " AND (b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)";
    params.push(`%${search}%`, `%${search}%`, `%${search}%`);
  }
  if (genre) { sql += " AND b.genre = ?"; params.push(genre); }
  sql += " ORDER BY b.title ASC";
  res.json(getDb().prepare(sql).all(...params));
});

// GET /api/books/genres
router.get("/genres", requireAuth, (req, res) => {
  const rows = getDb().prepare("SELECT DISTINCT genre FROM books WHERE genre != '' ORDER BY genre").all();
  res.json(rows.map(r => r.genre));
});

// GET /api/books/:id
router.get("/:id", requireAuth, (req, res) => {
  const book = getDb().prepare(BOOK_SELECT + " WHERE b.id = ?").get(req.params.id);
  if (!book) return res.status(404).json({ error: "Book not found." });
  res.json(book);
});

// POST /api/books
router.post("/", requireAdmin, (req, res) => {
  const { title, author, isbn, genre, total_copies } = req.body || {};
  if (!title?.trim()) return res.status(400).json({ error: "Title is required." });
  if (!author?.trim()) return res.status(400).json({ error: "Author is required." });
  const copies = Math.max(1, parseInt(total_copies) || 1);
  try {
    const r = getDb().prepare(
      "INSERT INTO books (title, author, isbn, genre, total_copies, available_copies) VALUES (?,?,?,?,?,?)"
    ).run(title.trim(), author.trim(), isbn?.trim() || null, genre?.trim() || "", copies, copies);
    res.status(201).json(getDb().prepare(BOOK_SELECT + " WHERE b.id = ?").get(r.lastInsertRowid));
  } catch (e) {
    if (e.message?.includes("UNIQUE")) return res.status(400).json({ error: "ISBN already exists." });
    throw e;
  }
});

// PUT /api/books/:id
router.put("/:id", requireAdmin, (req, res) => {
  const db   = getDb();
  const book = db.prepare("SELECT * FROM books WHERE id = ?").get(req.params.id);
  if (!book) return res.status(404).json({ error: "Book not found." });

  const { title, author, isbn, genre, total_copies } = req.body || {};
  const newTotal    = Math.max(1, parseInt(total_copies) || book.total_copies);
  const borrowed    = book.total_copies - book.available_copies;
  if (newTotal < borrowed)
    return res.status(400).json({ error: `Cannot reduce copies below currently borrowed amount (${borrowed}).` });
  const newAvail    = newTotal - borrowed;

  try {
    db.prepare(
      "UPDATE books SET title=?, author=?, isbn=?, genre=?, total_copies=?, available_copies=? WHERE id=?"
    ).run(
      title   ?? book.title,
      author  ?? book.author,
      isbn    !== undefined ? (isbn?.trim() || null) : book.isbn,
      genre   ?? book.genre,
      newTotal, newAvail, req.params.id
    );
    res.json(getDb().prepare(BOOK_SELECT + " WHERE b.id = ?").get(req.params.id));
  } catch (e) {
    if (e.message?.includes("UNIQUE")) return res.status(400).json({ error: "ISBN already exists." });
    throw e;
  }
});

// DELETE /api/books/:id
router.delete("/:id", requireAdmin, (req, res) => {
  const db = getDb();
  const active = db.prepare(
    "SELECT COUNT(*) AS c FROM loans WHERE book_id = ? AND status = 'active'"
  ).get(req.params.id).c;
  if (active > 0)
    return res.status(400).json({ error: `Cannot delete — this book has ${active} active loan(s).` });
  db.prepare("DELETE FROM books WHERE id = ?").run(req.params.id);
  res.json({ ok: true });
});

module.exports = router;
