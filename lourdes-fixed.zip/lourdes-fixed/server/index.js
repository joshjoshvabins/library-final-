"use strict";
/**
 * Our Lady of Lourdes Library System — Server
 *
 * ENV VARS (set in .env locally, or in Render/Railway dashboard):
 *   PORT            default 5000
 *   SESSION_SECRET  CHANGE THIS for any public deployment
 *   CLIENT_URL      comma-separated allowed frontend origins
 *                   e.g. "https://lourdes-lib.vercel.app" or "*" for ngrok demos
 *   NODE_ENV        "production" | "development"
 */
const express = require("express");
const cors    = require("cors");
const session = require("express-session");
const path    = require("path");
const { initDb } = require("./db");

// Load .env file when present (local dev)
try { require("dotenv").config(); } catch (_) {}

const app     = express();
const PORT    = parseInt(process.env.PORT || "5000", 10);
const IS_PROD = process.env.NODE_ENV === "production";

// ── CORS ──────────────────────────────────────────────────────────────────────
const rawOrigins = process.env.CLIENT_URL || "http://localhost:5173";
const allowedOrigins = rawOrigins.split(",").map(s => s.trim());

app.use(cors({
  origin: (origin, cb) => {
    if (!origin) return cb(null, true);                    // same-origin / curl
    if (allowedOrigins.includes("*")) return cb(null, true); // open for demos
    if (allowedOrigins.includes(origin)) return cb(null, true);
    cb(new Error(`CORS blocked: ${origin}`));
  },
  credentials: true,
}));

// ── Middleware ────────────────────────────────────────────────────────────────
app.use(express.json());
app.use(session({
  secret: process.env.SESSION_SECRET || "INSECURE_CHANGE_ME",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    secure:   IS_PROD,                  // HTTPS only in production
    sameSite: IS_PROD ? "none" : "lax", // cross-origin cookies need "none"
    maxAge: 8 * 60 * 60 * 1000,
  },
}));

// ── API Routes ────────────────────────────────────────────────────────────────
app.use("/api/auth",    require("./routes/auth"));
app.use("/api/books",   require("./routes/books"));
app.use("/api/members", require("./routes/members"));
app.use("/api/loans",   require("./routes/loans"));
app.get("/api/health",  (_req, res) => res.json({ status: "ok", env: process.env.NODE_ENV || "dev" }));

// ── Serve built React app (Render single-service / production) ───────────────
const DIST = path.join(__dirname, "../client/dist");
if (IS_PROD) {
  app.use(express.static(DIST));
  app.get("*", (req, res) => {
    if (!req.path.startsWith("/api"))
      res.sendFile(path.join(DIST, "index.html"));
  });
}

// ── Error handler ─────────────────────────────────────────────────────────────
app.use((err, _req, res, _next) => {
  console.error("Server error:", err.message);
  res.status(500).json({ error: "Internal server error" });
});

// ── Listen on 0.0.0.0 — required for Docker / Render / any public host ───────
initDb();
app.listen(PORT, "0.0.0.0", () => {
  console.log("\n  📚  Our Lady of Lourdes Library System");
  console.log(`  🚀  http://0.0.0.0:${PORT}  [${IS_PROD ? "PRODUCTION" : "development"}]`);
  console.log("  🔑  admin / lourdes123\n");
});
