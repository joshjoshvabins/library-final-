const { DatabaseSync } = require("node:sqlite");
const path = require("path");

const db = new DatabaseSync(path.join(__dirname, "library.db"));

db.exec("PRAGMA journal_mode = WAL");
db.exec("PRAGMA foreign_keys = ON");

function hashPw(plain) { return String(plain); }
function checkPw(plain, stored) { return String(plain) === String(stored); }

function initDb() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'student',
      member_id INTEGER REFERENCES members(id) ON DELETE SET NULL,
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS books (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      author TEXT NOT NULL,
      isbn TEXT UNIQUE,
      genre TEXT NOT NULL DEFAULT '',
      total_copies INTEGER NOT NULL DEFAULT 1,
      available_copies INTEGER NOT NULL DEFAULT 1,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS members (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_id TEXT NOT NULL UNIQUE COLLATE NOCASE,
      name TEXT NOT NULL,
      grade TEXT NOT NULL DEFAULT '',
      contact TEXT NOT NULL DEFAULT '',
      type TEXT NOT NULL DEFAULT 'student',
      status TEXT NOT NULL DEFAULT 'active',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  db.exec(`
    CREATE TABLE IF NOT EXISTS loans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      book_id INTEGER NOT NULL REFERENCES books(id),
      member_id INTEGER NOT NULL REFERENCES members(id),
      borrow_date TEXT NOT NULL DEFAULT (date('now')),
      due_date TEXT NOT NULL,
      return_date TEXT,
      fine REAL NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'active',
      processed_by TEXT NOT NULL DEFAULT 'admin',
      notes TEXT NOT NULL DEFAULT '',
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  // Admin account only — no sample members
  if (db.prepare("SELECT COUNT(*) AS c FROM users").get().c === 0) {
    db.prepare("INSERT INTO users (username, password, role) VALUES (?,?,?)").run("admin", "lourdes123", "admin");
  }

  // Sample books
  if (db.prepare("SELECT COUNT(*) AS c FROM books").get().c === 0) {
    const ins = db.prepare("INSERT INTO books (title, author, isbn, genre, total_copies, available_copies) VALUES (?,?,?,?,?,?)");
    [
      // Filipino Classics
      ["Noli Me Tangere",                        "José Rizal",                  "978-9712908088", "Filipino Classic", 5, 5],
      ["El Filibusterismo",                      "José Rizal",                  "978-9712908095", "Filipino Classic", 5, 5],
      ["Florante at Laura",                      "Francisco Balagtas",          "978-9712927690", "Filipino Classic", 4, 4],
      ["Ibong Adarna",                           "Anonymous",                   "978-9712704437", "Filipino Classic", 4, 4],
      ["Banaag at Sikat",                        "Lope K. Santos",              "978-9712919619", "Filipino Classic", 3, 3],
      ["Mga Kwento ni Lola Basyang",             "Severino Reyes",              "978-9712712746", "Filipino Classic", 3, 3],

      // Fiction
      ["The Alchemist",                          "Paulo Coelho",                "978-0062315007", "Fiction",          5, 5],
      ["To Kill a Mockingbird",                  "Harper Lee",                  "978-0061935466", "Fiction",          4, 4],
      ["The Great Gatsby",                       "F. Scott Fitzgerald",         "978-0743273565", "Fiction",          3, 3],
      ["Of Mice and Men",                        "John Steinbeck",              "978-0140177398", "Fiction",          3, 3],
      ["The Old Man and the Sea",                "Ernest Hemingway",            "978-0684801223", "Fiction",          3, 3],
      ["Pride and Prejudice",                    "Jane Austen",                 "978-0141439518", "Fiction",          4, 4],
      ["The Catcher in the Rye",                 "J.D. Salinger",               "978-0316769174", "Fiction",          3, 3],
      ["Lord of the Flies",                      "William Golding",             "978-0399501487", "Fiction",          4, 4],
      ["Animal Farm",                            "George Orwell",               "978-0451526342", "Fiction",          4, 4],
      ["1984",                                   "George Orwell",               "978-0451524935", "Fiction",          4, 4],

      // Fantasy & Adventure
      ["Harry Potter and the Sorcerer's Stone",  "J.K. Rowling",                "978-0439708180", "Fantasy",          6, 6],
      ["Harry Potter and the Chamber of Secrets","J.K. Rowling",                "978-0439064873", "Fantasy",          5, 5],
      ["The Hobbit",                             "J.R.R. Tolkien",              "978-0547928227", "Fantasy",          4, 4],
      ["The Lion, the Witch and the Wardrobe",   "C.S. Lewis",                  "978-0064404990", "Fantasy",          4, 4],
      ["The Little Prince",                      "Antoine de Saint-Exupéry",    "978-0156012195", "Fantasy",          5, 5],

      // Non-Fiction
      ["Sapiens: A Brief History of Humankind",  "Yuval Noah Harari",           "978-0062316097", "Non-Fiction",      3, 3],
      ["Atomic Habits",                          "James Clear",                 "978-0735211292", "Non-Fiction",      4, 4],
      ["The 7 Habits of Highly Effective People","Stephen R. Covey",            "978-0743269513", "Non-Fiction",      3, 3],
      ["Thinking, Fast and Slow",                "Daniel Kahneman",             "978-0374533557", "Non-Fiction",      2, 2],
      ["How to Win Friends and Influence People", "Dale Carnegie",              "978-0671027032", "Non-Fiction",      3, 3],
      ["Rich Dad Poor Dad",                      "Robert T. Kiyosaki",          "978-1612680194", "Non-Fiction",      3, 3],
      ["The Power of Now",                       "Eckhart Tolle",               "978-1577314806", "Non-Fiction",      2, 2],

      // Science & Technology
      ["A Brief History of Time",                "Stephen Hawking",             "978-0553380163", "Science",          3, 3],
      ["The Theory of Everything",               "Stephen Hawking",             "978-1897445365", "Science",          2, 2],
      ["Cosmos",                                 "Carl Sagan",                  "978-0345331359", "Science",          3, 3],

      // Children & Young Adult
      ["Charlotte's Web",                        "E.B. White",                  "978-0061124952", "Children",         5, 5],
      ["The Diary of a Young Girl",              "Anne Frank",                  "978-0553296983", "Children",         4, 4],
      ["Wonder",                                 "R.J. Palacio",                "978-0375869020", "Young Adult",      4, 4],
      ["The Hunger Games",                       "Suzanne Collins",             "978-0439023481", "Young Adult",      5, 5],
      ["Divergent",                              "Veronica Roth",               "978-0062024039", "Young Adult",      4, 4],

      // History & Biography
      ["The Story of My Experiments with Truth", "Mahatma Gandhi",              "978-0807059098", "Biography",        2, 2],
      ["Long Walk to Freedom",                   "Nelson Mandela",              "978-0316548182", "Biography",        2, 2],
    ].forEach(b => ins.run(...b));
  }

  console.log("Database ready.");
  return db;
}

function getDb() { return db; }

module.exports = { getDb, initDb, hashPw, checkPw };
